import requests
from bs4 import BeautifulSoup
from colorama import Fore, Style, init
import random
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
import os
import json

init(autoreset=True)

# Configurações
MAX_THREADS = 15
TIMEOUT = 20
USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1',
    'Mozilla/5.0 (Linux; Android 10; SM-G980F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36'
]

class UsernameChecker:
    def __init__(self):
        self.session = requests.Session()
        self.stats = {
            "total": 0,
            "live": 0,
            "forsale": 0,
            "die": 0,
            "error": 0
        }
        self.start_time = time.time()
        self.results = {
            "live": [],
            "forsale": [],
            "die": [],
            "error": []
        }

    def get_random_headers(self):
        return {
            'User-Agent': random.choice(USER_AGENTS),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive'
        }

    def check_fragment(self, username):
        try:
            url = f"https://fragment.com/?query={username}"
            response = self.session.get(url, headers=self.get_random_headers(), timeout=TIMEOUT)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            result = soup.find('a', class_='table-cell')
            
            if result and username.lower() in result.text.lower():
                status = result.find('div', class_='table-cell-status-thin')
                if status and 'Available' in status.text:
                    return "FORSALE"
                return "DIE"
            return "LIVE"
        except Exception:
            return "ERROR"

    def check_telegram(self, username):
        try:
            url = f"https://t.me/{username}"
            response = self.session.get(url, headers=self.get_random_headers(), timeout=TIMEOUT)
            response.raise_for_status()
            
            if 'tgme_page_title' in response.text or 'View in Telegram' in response.text:
                return "DIE"
            return "LIVE"
        except Exception:
            return "ERROR"

    def check_username(self, username):
        username = username.strip().replace('@', '')
        if not username or len(username) < 5:
            return None, username
            
        self.stats["total"] += 1
        
        fragment_result = self.check_fragment(username)
        telegram_result = self.check_telegram(username)

        if "ERROR" in [fragment_result, telegram_result]:
            self.stats["error"] += 1
            self.results["error"].append(username)
            return "ERROR", username

        if fragment_result == "FORSALE":
            self.stats["forsale"] += 1
            self.results["forsale"].append(username)
            return "FORSALE", username
        elif fragment_result == "LIVE" and telegram_result == "LIVE":
            self.stats["live"] += 1
            self.results["live"].append(username)
            return "LIVE", username
        else:
            self.stats["die"] += 1
            self.results["die"].append(username)
            return "DIE", username

    def save_results(self):
        for status in self.results:
            with open(f'{status}.txt', 'w', encoding='utf-8') as f:
                for username in self.results[status]:
                    f.write(f"@{username}\n")

            with open(f'{status}_raw.txt', 'w', encoding='utf-8') as f:
                f.write('\n'.join(self.results[status]))

        with open('summary.json', 'w') as f:
            json.dump({
                "stats": self.stats,
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                "duration": time.time() - self.start_time
            }, f, indent=4)

    def show_panel(self):
        elapsed = time.time() - self.start_time
        print("\033[H\033[J", end='')
        print(Fore.CYAN + "══════════════════════════════════")
        print(Fore.YELLOW + "       USERNAME CHECKER v2.0")
        print(Fore.CYAN + "══════════════════════════════════")
        print(f"{Fore.GREEN}✅ Live: {self.stats['live']}")
        print(f"{Fore.YELLOW}💰 For Sale: {self.stats['forsale']}")
        print(f"{Fore.RED}❌ Dead: {self.stats['die']}")
        print(f"{Fore.MAGENTA}⚠ Errors: {self.stats['error']}")
        print(Fore.CYAN + "══════════════════════════════════")
        print(f"{Fore.WHITE}Total: {self.stats['total']}")
        print(f"Time: {elapsed:.2f}s")
        print(Fore.CYAN + "══════════════════════════════════", flush=True)

def main():
    checker = UsernameChecker()
    
    # Verifica e carrega a wordlist
    wordlist_path = input("Enter path to username list: ").strip('"')
    if not os.path.exists(wordlist_path):
        print(Fore.RED + "Error: File not found!")
        return

    try:
        with open(wordlist_path, 'r', encoding='utf-8') as file:
            usernames = list({line.strip().replace('@', '') for line in file if line.strip()})
    except Exception as e:
        print(Fore.RED + f"Error reading file: {e}")
        return

    print(Fore.GREEN + f"\nLoaded {len(usernames)} unique usernames\n")

    # Processamento em lote
    batch_size = 50
    for i in range(0, len(usernames), batch_size):
        batch = usernames[i:i + batch_size]
        
        with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
            futures = {executor.submit(checker.check_username, username): username for username in batch}
            
            for future in as_completed(futures):
                status, username = future.result()
                if status == "LIVE":
                    print(f"{Fore.GREEN}[LIVE] @{username}")
                elif status == "FORSALE":
                    print(f"{Fore.YELLOW}[FORSALE] @{username}")
                elif status == "DIE":
                    print(f"{Fore.RED}[DIE] @{username}")
                elif status == "ERROR":
                    print(f"{Fore.MAGENTA}[ERROR] @{username}")
                
                checker.show_panel()
        
        # Pausa entre lotes para evitar bloqueio
        if i + batch_size < len(usernames):
            time.sleep(5)

    # Salva resultados
    checker.save_results()
    
    print(Fore.GREEN + "\nVerification completed!")
    print(Fore.CYAN + "Results saved in /results folder")
    print(Fore.YELLOW + f"Live usernames: {len(checker.results['live'])}")
    print(Fore.YELLOW + f"For sale: {len(checker.results['forsale'])}")

if __name__ == "__main__":
    main()