import requests
import time
from itertools import cycle
from concurrent.futures import ThreadPoolExecutor, as_completed
from colorama import init, Fore, Style
import os

init(autoreset=True)

class SpotifyChecker:
    def __init__(self):
        self.stats = {
            'total': 0,
            'registered': 0,
            'unregistered': 0,
            'errors': 0,
            'start_time': time.time()
        }
        self.proxy_cycle = None

    def show_panel(self):
        elapsed = time.time() - self.stats['start_time']
        print("\033[H\033[J")  # Clear terminal
        print(Fore.CYAN + "══════════════════════════════════")
        print(Fore.YELLOW + "    SPOTIFY EMAIL VALIDATOR")
        print(Fore.CYAN + "══════════════════════════════════")
        print(Fore.GREEN + f" ✅ REGISTERED: {self.stats['registered']}")
        print(Fore.RED + f" ❌ UNREGISTERED: {self.stats['unregistered']}")
        print(Fore.YELLOW + f" ⚠ ERRORS: {self.stats['errors']}")
        print(Fore.CYAN + "══════════════════════════════════")
        print(f"{Fore.WHITE}Total: {self.stats['total']}")
        print(f"Tempo: {elapsed:.2f}s")
        print(Fore.CYAN + "══════════════════════════════════")

    def read_file(self, file_path):
        try:
            with open(file_path, 'r') as file:
                return [line.strip() for line in file if line.strip()]
        except Exception as e:
            print(Fore.RED + f"Error reading file: {e}")
            return None

    def parse_proxy(self, proxy):
        if proxy.startswith(("http://", "https://", "socks4://", "socks5://")):
            return {"http": proxy, "https": proxy}
        return {"http": f"http://{proxy}", "https": f"http://{proxy}"}

    def check_email(self, email):
        url = f"https://spclient.wg.spotify.com/signup/public/v1/account/?validate=1&suggest=1&key=142b583129b2df829de3656f9eb484e6&email={email}"
        headers = {
            "User-Agent": "Spotify/8.7.6.1087 Android/22 (SM-G988N)",
            "Spotify-App-Version": "8.7.6.1087",
            "Accept-Language": "en-US"
        }

        proxy = next(self.proxy_cycle)
        proxies = self.parse_proxy(proxy)

        try:
            response = requests.get(url, headers=headers, proxies=proxies, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if data.get('status') == 20 and 'already registered' in str(data.get('errors', {})):
                    return True, email
            return False, email
        except Exception:
            return None, email

    def process_email(self, email):
        result, email = self.check_email(email)
        while result is None:  # Retry with new proxy if error
            result, email = self.check_email(email)
        return result, email

    def save_results(self, valid_emails, invalid_emails):
        with open('live.txt', 'w') as f:
            f.write('\n'.join(valid_emails))
        with open('die.txt', 'w') as f:
            f.write('\n'.join(invalid_emails))

    def main(self):
        print(Fore.CYAN + "Enter email file path: ")
        email_file = input().strip()
        print(Fore.CYAN + "Enter proxy file path: ")
        proxy_file = input().strip()
        print(Fore.CYAN + "Enter thread count: ")
        threads = int(input().strip())

        emails = self.read_file(email_file)
        proxies = self.read_file(proxy_file)

        if not emails or not proxies:
            return

        self.proxy_cycle = cycle(proxies)
        self.stats['total'] = len(emails)

        valid_emails = []
        invalid_emails = []

        with ThreadPoolExecutor(max_workers=threads) as executor:
            futures = {executor.submit(self.process_email, email): email for email in emails}
            
            for future in as_completed(futures):
                result, email = future.result()
                if result:
                    valid_emails.append(email)
                    self.stats['registered'] += 1
                    print(Fore.GREEN + f"[+] REGISTERED: {email}")
                else:
                    invalid_emails.append(email)
                    self.stats['unregistered'] += 1
                    print(Fore.RED + f"[-] UNREGISTERED: {email}")
                self.show_panel()

        self.save_results(valid_emails, invalid_emails)
        print(Fore.GREEN + "\nResults saved to live.txt and die.txt")

if __name__ == "__main__":
    checker = SpotifyChecker()
    checker.main()